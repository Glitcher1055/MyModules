#pragma once

// Everything that touches Minecraft internals lives here.
//
// Signatures and memory offsets come from the open-source BedrockTools mod
// (github.com/QYCottage/BedrockTools, GPL-3.0, by RadiantByte). They were checked
// against libminecraftpe.so 1.26.50: every signature below matches exactly once.

#include <string>
#include <string_view>

namespace elytra::game {

enum class Kind { Empty, Elytra, Chestplate, Other };

// Where an item sits inside the open inventory screen.
struct SlotRef {
  const char *collection = nullptr; // "inventory_items" / "hotbar_items" / "armor_items"
  int index = -1;
  Kind kind = Kind::Empty;
  int rank = 0; // chestplate quality, higher is better
  [[nodiscard]] bool valid() const { return collection && index >= 0; }
};

struct Hooks {
  using TickFn = void (*)(void *player);
  using OpenFn = void *(*)(void *, void *, void *, void *, void *, void *, void *, void *);

  // Resolved addresses (0 when a signature was not found).
  void *tick = nullptr;
  void *open = nullptr;
  void *getStack = nullptr;     // ContainerScreenController::getItemStack (called while a container screen is up)
  void *slotSelected = nullptr; // ContainerScreenController slot "tap" handler

  // Human-readable "Name=0xADDR" list of every signature, filled by resolve()
  // (found or not), used for the diagnostic report.
  std::string detail;
};

// Resolves all signatures. Returns true only when every one was found.
// `missing` receives the names of the ones that were not.
bool resolve(Hooks &hooks, std::string &missing);

// --- Reading the inventory screen (only valid while `controller` is alive) ---

// What is in `collection[index]` of the open screen.
Kind readKind(void *controller, const char *collection, int index, int *rank = nullptr);

// Looks at the worn chest item and the inventory, and picks the item to swap in.
// `worn` receives what is currently worn. Returns an invalid ref when there is
// nothing to swap with.
SlotRef chooseSwapSlot(void *controller, Kind &worn);

// --- Acting on the inventory screen -----------------------------------------

// Same as shift-clicking the slot.
bool quickMove(void *controller, const char *collection, int index);

// Same as tapping the slot (select / place / swap).
bool tapSlot(void *controller, const char *collection, int index);

// While an InternalScope is alive on this thread, inInternalCall() is true. Our own
// calls into the game wrap themselves in one, so our hooks can recognise and ignore
// them (prevents recursion and deadlocks when the game calls a hooked function).
struct InternalScope {
  InternalScope();
  ~InternalScope();
  InternalScope(const InternalScope &) = delete;
  InternalScope &operator=(const InternalScope &) = delete;
};
bool inInternalCall();

// Decodes a std::string that lives at `p` in game memory, without trusting it.
bool readStdString(const void *p, std::string &out);

// Multi-line text listing what the open screen holds in the armor, hotbar and
// inventory collections, including raw pointers when a name could not be read.
// Used only for the diagnostic report.
std::string dumpInventory(void *controller);

// Reads the first pointer of the object (its vtable). Used to notice when the
// screen controller has been destroyed and replaced.
void *vtableOf(const void *object);

// Crash-safe read: returns false instead of crashing on a bad address.
bool safeRead(const void *src, void *dst, std::size_t size);

} // namespace elytra::game
