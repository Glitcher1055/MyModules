#include "game/Game.hpp"

#include <array>
#include <cerrno>
#include <climits>
#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <mutex>
#include <utility>

#include <dlfcn.h>
#include <unistd.h>

#include <pl/memory/Signature.hpp>

namespace elytra::game {
namespace {

constexpr const char *kModule = "libminecraftpe.so";

// ---------------------------------------------------------------------------
// Signatures (BedrockTools, verified against 1.26.50: each matches exactly once)
// ---------------------------------------------------------------------------
constexpr const char *kSigNormalTick =
    "? ? ? FC ? ? ? A9 ? ? ? A9 ? ? ? A9 ? ? ? A9 ? ? ? A9 ? ? ? A9 ? ? ? 91 ? ? ? D1 54 D0 3B D5 F3 03 00 AA ? ? ? F9 ? ? ? F8 ? ? ? 39";
constexpr const char *kSigContainerOpen =
    "? ? ? A9 ? ? ? F9 FD 03 00 91 F3 03 00 AA ? ? ? 94 ? ? ? F9 E1 03 1F 2A ? ? ? 94";
constexpr const char *kSigSlotSelected =
    "? ? ? A9 FD 03 00 91 ? ? ? F9 ? ? ? F9 00 01 3F D6 E0 03 1F 2A ? ? ? A8 C0 03 5F D6 ? ? ? D1";
constexpr const char *kSigGetItemStack =
    "? ? ? D1 ? ? ? A9 ? ? ? A9 ? ? ? 91 54 D0 3B D5 F3 03 00 AA ? ? ? 91 ? ? ? F9 ? ? ? F8 ? ? ? 95 ? ? ? F9 ? ? ? F9 ? ? ? 91";
constexpr const char *kSigAutoPlace =
    "? ? ? D1 ? ? ? A9 ? ? ? F9 ? ? ? A9 ? ? ? A9 ? ? ? A9 ? ? ? A9 ? ? ? 91 58 D0 3B D5 F3 03 03 2A F4 03 02 AA ? ? ? F9 F5 03 00 AA F6 03 01 2A ? ? ? F8 ? ? ? F9 ? ? ? F9";

// ---------------------------------------------------------------------------
// Memory layout (BedrockTools, include/bedrocktools/sdk/offsets/Inventory.hpp)
// ---------------------------------------------------------------------------
constexpr std::size_t kStackItemCounter = 0x8;  // ItemStack -> shared counter
constexpr std::size_t kStackCount = 0x22;       // uint8_t
constexpr std::size_t kStackValid = 0x23;       // uint8_t
constexpr std::size_t kItemGetDescriptionIdVtableIndex = 5;

// ---------------------------------------------------------------------------
// Game function types
// ---------------------------------------------------------------------------
using GetItemStackFn = const void *(*)(void *controller, const std::string &collection, int index);
using SlotSelectedFn = std::uint32_t (*)(void *controller, const std::string &collection, int index);
using AutoPlaceFn = void (*)(void *controller, int count, const std::string &collection, int index);
// Returns a reference to a std::string owned by the item; treated as a raw
// pointer here and decoded by hand (see decodeString) so garbage cannot crash us.
using GetDescriptionIdFn = const void *(*)(const void *item);

GetItemStackFn gGetItemStack = nullptr;
SlotSelectedFn gSlotSelected = nullptr;
AutoPlaceFn gAutoPlace = nullptr;

thread_local int gInternalDepth = 0;

std::uintptr_t resolveOne(const char *pattern) {
  return pl::memory::resolveSignature(pattern, kModule);
}

// ---------------------------------------------------------------------------
// safeRead: copy through a pipe. write() fails with EFAULT on a bad address
// instead of crashing the process.
// ---------------------------------------------------------------------------
struct Pipe {
  int fds[2] = {-1, -1};
  Pipe() {
    if (pipe(fds) != 0) fds[0] = fds[1] = -1;
  }
};

std::mutex gPipeMutex;

Kind classify(const std::string &id) {
  if (id.find("elytra") != std::string::npos) return Kind::Elytra;
  if (id.find("chestplate") != std::string::npos) return Kind::Chestplate;
  return Kind::Other;
}

int chestplateRank(const std::string &id) {
  constexpr std::array<std::string_view, 7> order = {
      "netherite", "diamond", "iron", "chainmail", "golden", "copper", "leather"};
  for (std::size_t i = 0; i < order.size(); ++i)
    if (id.find(order[i]) != std::string::npos) return static_cast<int>(order.size() - i);
  return 0;
}

template <class T>
bool readAt(const void *base, std::size_t offset, T &out) {
  return safeRead(static_cast<const std::byte *>(base) + offset, &out, sizeof(T));
}

// Decodes a libc++ (NDK) std::string at `p` without trusting it: every read goes
// through safeRead and the text must be short, printable ASCII.
bool decodeString(const void *p, std::string &out) {
  unsigned char raw[24];
  if (!safeRead(p, raw, sizeof(raw))) return false;

  std::string text;
  if ((raw[0] & 1) == 0) {
    // Short string: size in the first byte (<< 1), characters follow inline.
    const std::size_t n = raw[0] >> 1;
    if (n == 0 || n > 22) return false;
    text.assign(reinterpret_cast<const char *>(raw + 1), n);
  } else {
    // Long string: size at +8, data pointer at +16.
    std::size_t n = 0;
    const char *data = nullptr;
    std::memcpy(&n, raw + 8, sizeof(n));
    std::memcpy(&data, raw + 16, sizeof(data));
    if (n == 0 || n > 128 || !data) return false;
    char chunk[64];
    for (std::size_t done = 0; done < n;) {
      const std::size_t part = (n - done) < sizeof(chunk) ? (n - done) : sizeof(chunk);
      if (!safeRead(data + done, chunk, part)) return false;
      text.append(chunk, part);
      done += part;
    }
  }

  for (const char c : text)
    if (c < 0x20 || c > 0x7e) return false;
  out = std::move(text);
  return true;
}

// True when `fn` lies inside libminecraftpe.so (guards against a wrong vtable slot).
bool insideGame(std::uintptr_t fn) {
  Dl_info info{};
  if (!dladdr(reinterpret_cast<void *>(fn), &info) || !info.dli_fname) return false;
  return std::strstr(info.dli_fname, "libminecraftpe") != nullptr;
}

// Why reading a stack's name failed, or "ok". `id` receives the name on success.
// Reads the item description id ("item.elytra", "item.diamond_chestplate", ...).
const char *describeWhy(const void *stack, std::string &id) {
  if (!stack) return "stack null";

  std::uint8_t valid = 0, count = 0;
  if (!readAt(stack, kStackValid, valid)) return "stack unreadable";
  if (!valid) return "empty";
  if (!readAt(stack, kStackCount, count)) return "stack unreadable";
  if (count == 0) return "empty";

  const void *counter = nullptr;
  if (!readAt(stack, kStackItemCounter, counter) || !counter) return "no item counter";

  const void *item = nullptr;
  if (!safeRead(counter, &item, sizeof(item)) || !item) return "no item pointer";

  const std::uintptr_t *vtable = nullptr;
  if (!safeRead(item, &vtable, sizeof(vtable)) || !vtable) return "no vtable";

  std::uintptr_t fn = 0;
  if (!safeRead(vtable + kItemGetDescriptionIdVtableIndex, &fn, sizeof(fn)) || !fn)
    return "no function in vtable slot";
  if (!insideGame(fn)) return "vtable slot is not game code";

  const void *name = reinterpret_cast<GetDescriptionIdFn>(fn)(item);
  if (!decodeString(name, id)) return "name unreadable";
  return "ok";
}

// Reads the item description id of a stack. Returns false for empty or unreadable stacks.
bool describe(const void *stack, std::string &id) {
  return std::strcmp(describeWhy(stack, id), "ok") == 0;
}

} // namespace

// ---------------------------------------------------------------------------

InternalScope::InternalScope() { ++gInternalDepth; }
InternalScope::~InternalScope() { --gInternalDepth; }
bool inInternalCall() { return gInternalDepth > 0; }

bool readStdString(const void *p, std::string &out) { return decodeString(p, out); }

bool safeRead(const void *src, void *dst, std::size_t size) {
  static Pipe pipeHolder;
  if (!src || !dst || size == 0 || size > 64) return false;
  if (pipeHolder.fds[0] < 0) return false;

  std::lock_guard<std::mutex> lock(gPipeMutex);
  const ssize_t written = write(pipeHolder.fds[1], src, size);
  if (written != static_cast<ssize_t>(size)) {
    // Drain whatever partial data may have been queued.
    if (written > 0) {
      std::byte tmp[64];
      (void)read(pipeHolder.fds[0], tmp, static_cast<std::size_t>(written));
    }
    return false;
  }
  return read(pipeHolder.fds[0], dst, size) == static_cast<ssize_t>(size);
}

void *vtableOf(const void *object) {
  void *vt = nullptr;
  if (!safeRead(object, &vt, sizeof(vt))) return nullptr;
  return vt;
}

bool resolve(Hooks &hooks, std::string &missing) {
  struct Entry {
    const char *name;
    const char *pattern;
    std::uintptr_t addr;
  };
  std::array<Entry, 5> entries = {{
      {"NormalTick", kSigNormalTick, 0},
      {"ContainerScreenControllerOpen", kSigContainerOpen, 0},
      {"OnContainerSlotSelected", kSigSlotSelected, 0},
      {"GetItemStack", kSigGetItemStack, 0},
      {"HandleAutoPlace", kSigAutoPlace, 0},
  }};

  missing.clear();
  hooks.detail.clear();
  for (auto &e : entries) {
    e.addr = resolveOne(e.pattern);
    char buf[96];
    std::snprintf(buf, sizeof(buf), "%s=0x%llx ", e.name, static_cast<unsigned long long>(e.addr));
    hooks.detail += buf;
    if (!e.addr) {
      if (!missing.empty()) missing += ", ";
      missing += e.name;
    }
  }
  if (!missing.empty()) return false;

  hooks.tick = reinterpret_cast<void *>(entries[0].addr);
  hooks.open = reinterpret_cast<void *>(entries[1].addr);
  hooks.slotSelected = reinterpret_cast<void *>(entries[2].addr);
  hooks.getStack = reinterpret_cast<void *>(entries[3].addr);
  gSlotSelected = reinterpret_cast<SlotSelectedFn>(entries[2].addr);
  gGetItemStack = reinterpret_cast<GetItemStackFn>(entries[3].addr);
  gAutoPlace = reinterpret_cast<AutoPlaceFn>(entries[4].addr);
  return true;
}

Kind readKind(void *controller, const char *collection, int index, int *rank) {
  if (rank) *rank = 0;
  if (!controller || !gGetItemStack) return Kind::Empty;

  InternalScope scope;
  const std::string name(collection);
  const void *stack = gGetItemStack(controller, name, index);

  std::string id;
  if (!describe(stack, id)) return Kind::Empty;

  const Kind kind = classify(id);
  if (rank && kind == Kind::Chestplate) *rank = chestplateRank(id);
  return kind;
}

SlotRef chooseSwapSlot(void *controller, Kind &worn) {
  worn = readKind(controller, "armor_items", 1);

  // Elytra worn      -> look for the best chestplate.
  // Chestplate worn  -> look for elytra.
  // Nothing worn     -> prefer elytra, otherwise the best chestplate.
  const bool wantElytra = (worn != Kind::Elytra);
  const bool wantChestplate = (worn != Kind::Chestplate);

  SlotRef best;

  auto consider = [&](const char *collection, int count) {
    for (int i = 0; i < count; ++i) {
      int rank = 0;
      const Kind kind = readKind(controller, collection, i, &rank);
      if (kind == Kind::Elytra && wantElytra) {
        // First elytra wins; it beats any chestplate found so far.
        if (best.kind != Kind::Elytra) {
          best = SlotRef{collection, i, Kind::Elytra, 1000};
        }
      } else if (kind == Kind::Chestplate && wantChestplate && best.kind != Kind::Elytra) {
        if (!best.valid() || rank > best.rank) {
          best = SlotRef{collection, i, Kind::Chestplate, rank};
        }
      }
    }
  };

  consider("hotbar_items", 9);
  consider("inventory_items", 27);
  return best;
}

std::string dumpInventory(void *controller) {
  if (!controller || !gGetItemStack) return "  (no controller or GetItemStack missing)\n";

  InternalScope scope;
  struct Part {
    const char *name;
    int count;
  };
  const Part parts[] = {{"armor_items", 4}, {"hotbar_items", 9}, {"inventory_items", 27}};

  std::string out;
  char buf[320];
  int empty = 0;
  for (const Part &part : parts) {
    for (int i = 0; i < part.count; ++i) {
      const std::string collection(part.name);
      const void *stack = gGetItemStack(controller, collection, i);

      std::string id;
      const char *why = describeWhy(stack, id);
      if (std::strcmp(why, "empty") == 0) {
        ++empty;
        continue;
      }
      if (std::strcmp(why, "ok") == 0) {
        std::uint8_t count = 0;
        readAt(stack, kStackCount, count);
        std::snprintf(buf, sizeof(buf), "  %s[%d]: x%u %s -> %s\n", part.name, i,
                      static_cast<unsigned>(count), id.c_str(),
                      classify(id) == Kind::Elytra       ? "ELYTRA"
                      : classify(id) == Kind::Chestplate ? "CHESTPLATE"
                                                         : "other");
      } else {
        // Raw view of the object chain, to work out the right offsets.
        const void *counter = nullptr, *item = nullptr, *vtable = nullptr;
        std::uint8_t valid = 0, count = 0;
        if (stack) {
          readAt(stack, kStackValid, valid);
          readAt(stack, kStackCount, count);
          readAt(stack, kStackItemCounter, counter);
          if (counter) safeRead(counter, &item, sizeof(item));
          if (item) safeRead(item, &vtable, sizeof(vtable));
        }
        std::snprintf(buf, sizeof(buf),
                      "  %s[%d]: FAILED (%s) stack=%p valid=%u count=%u counter=%p item=%p vtable=%p\n",
                      part.name, i, why, static_cast<const void *>(stack),
                      static_cast<unsigned>(valid), static_cast<unsigned>(count), counter, item,
                      vtable);
      }
      out += buf;
    }
  }
  std::snprintf(buf, sizeof(buf), "  (%d empty slots not listed)\n", empty);
  out += buf;
  return out;
}

bool quickMove(void *controller, const char *collection, int index) {
  if (!controller || !gAutoPlace) return false;
  InternalScope scope;
  gAutoPlace(controller, INT_MAX, std::string(collection), index);
  return true;
}

bool tapSlot(void *controller, const char *collection, int index) {
  if (!controller || !gSlotSelected) return false;
  InternalScope scope;
  gSlotSelected(controller, std::string(collection), index);
  return true;
}

} // namespace elytra::game
