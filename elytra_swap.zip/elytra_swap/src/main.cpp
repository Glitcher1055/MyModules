// Entry point. PL_REGISTER_MOD must be used exactly once, here.
#include <pl/Mod.hpp>

#include "ElytraSwapMod.hpp"

PL_REGISTER_MOD(ElytraSwapMod, ElytraSwapMod::instance())
