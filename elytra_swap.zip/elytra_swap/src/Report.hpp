#pragma once

#include <filesystem>
#include <string>

// A tiny text report written next to the mod and to the launcher's media folder,
// so a person can send it back when something does not work. Thread-safe.
namespace elytra::report {

// Opens (and truncates) the report files. Safe to call more than once.
void init(const std::filesystem::path &dataDir);

// printf-style, one timestamped entry per call (may span several lines).
void line(const char *fmt, ...) __attribute__((format(printf, 1, 2)));

// Where the main copy of the report is written.
std::string primaryPath();

} // namespace elytra::report
