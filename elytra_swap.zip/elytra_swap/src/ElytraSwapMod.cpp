#include "ElytraSwapMod.hpp"

#include <atomic>
#include <chrono>
#include <span>
#include <string_view>

#include <dlfcn.h>

#include <pl/ModMenu.hpp>

#include "Icon.hpp"
#include "Report.hpp"

namespace game = elytra::game;
namespace report = elytra::report;

namespace {

constexpr const char *ModuleId = "elytra_swap.module";
constexpr const char *ButtonId = "elytra_swap.swap";

// Android KEYCODE_E. The on-screen button sends this key to the game, which is
// the default "open inventory" key. Change it if you rebound the key in game.
constexpr int InventoryKeyCode = 33;
// Key code for the launcher's native key helper: it takes Windows/Bedrock codes
// (letter keys = their capital ASCII letter), not Android codes. 'E' = 69.
constexpr int GameKeyE = 69;

// How long after a button press an opening inventory screen counts as ours.
constexpr long long RequestWindowMs = 2500;
// Game ticks (1 tick = 50 ms) to let the screen finish building after it opens.

// Game ticks between two actions on the screen.

// Safety limit: give up if the whole thing takes longer than this many ticks.
constexpr int MaxActiveTicks = 40;
// Ignore a second press within this time.
constexpr long long DebounceMs = 300;
// Ticks to wait for the freshly opened screen to fill in / for one action to take effect.
constexpr int SettleMaxTicks = 8;
constexpr int ActionMaxTicks = 3;

using TickFn = void (*)(void *);
using OpenFn = void *(*)(void *, void *, void *, void *, void *, void *, void *, void *);

using GetStackFn = const void *(*)(void *, const std::string *, int);
using SlotFn = unsigned (*)(void *, const std::string *, int);

TickFn gOriginalTick = nullptr;
OpenFn gOriginalOpen = nullptr;
GetStackFn gOriginalGetStack = nullptr;
SlotFn gOriginalSlot = nullptr;

long long nowMs() {
  using namespace std::chrono;
  return duration_cast<milliseconds>(steady_clock::now().time_since_epoch()).count();
}

const char *kindName(game::Kind kind) {
  switch (kind) {
  case game::Kind::Empty: return "empty";
  case game::Kind::Elytra: return "elytra";
  case game::Kind::Chestplate: return "chestplate";
  default: return "other";
  }
}

// Presses a key in the game through the launcher's own native helper
// (the same one its on-screen buttons use). Returns false if it is unavailable.
bool sendGameKey(int keyCode, bool down) {
  using InitFn = unsigned char (*)(void *, void *);
  using KeyFn = void (*)(void *, void *, int, unsigned char);
  static InitFn init = nullptr;
  static KeyFn send = nullptr;
  static bool tried = false;
  if (!tried) {
    tried = true;
    void *lib = dlopen("libinbuiltmods.so", RTLD_NOW | RTLD_NOLOAD);
    if (!lib) lib = dlopen("libinbuiltmods.so", RTLD_NOW);
    if (lib) {
      init = reinterpret_cast<InitFn>(dlsym(
          lib, "Java_org_levimc_launcher_core_mods_inbuilt_nativemod_MoreButtonsMod_nativeInit"));
      send = reinterpret_cast<KeyFn>(dlsym(
          lib, "Java_org_levimc_launcher_core_mods_inbuilt_nativemod_MoreButtonsMod_nativeSendKey"));
    }
    report::line("Key helper: lib=%p init=%p send=%p", lib, reinterpret_cast<void *>(init),
                 reinterpret_cast<void *>(send));
    if (init) init(nullptr, nullptr);
  }
  if (!send) return false;
  send(nullptr, nullptr, keyCode, down ? 1 : 0);
  return true;
}

} // namespace

ElytraSwapMod &ElytraSwapMod::instance() {
  static ElytraSwapMod inst;
  return inst;
}

ElytraSwapMod::ElytraSwapMod() : mSelf(*ll::mod::NativeMod::current()) {}

bool ElytraSwapMod::load() {
  auto &self = getSelf();
  report::init(self.getDataDir());
  report::line("Elytra Swap 0.4.0 (diagnostic report). Loaded as '%s'.", self.getName().c_str());
  report::line("Report file: %s", report::primaryPath().c_str());
  self.getLogger().info("Loaded {}. Report file: {}", self.getName(), report::primaryPath());
  return true;
}

bool ElytraSwapMod::enable() {
  auto &self = getSelf();

  const bool moduleOk =
      pl::modmenu::ModuleBuilder(ModuleId, "Elytra Swap")
          .modId(self.getId())
          .description("Swap elytra and chestplate with one button.")
          .defaultEnabled(true)
          .onToggle([](std::string_view, bool enabled) { instance().mActive.store(enabled); })
          .registerModule();

  const bool buttonOk =
      pl::modmenu::ButtonBuilder(ButtonId, "Elytra Swap")
          .modId(self.getId())
          .moduleId(ModuleId)
          .label("Swap")
          .pngIcon(std::span<const unsigned char>(kButtonIconPng, sizeof(kButtonIconPng)))
          .androidKeyCode(InventoryKeyCode)
          .behavior(pl::modmenu::ButtonBehavior::Click)
          .onEvent([](std::string_view, pl::modmenu::ButtonEvent event, float) {
            if (event == pl::modmenu::ButtonEvent::Click ||
                event == pl::modmenu::ButtonEvent::Down) {
              instance().requestSwap();
            }
          })
          .registerButton();

  self.getLogger().info("Elytra Swap: menu module {}, button {}", moduleOk, buttonOk);
  report::line("enable(): menu module registered=%d, button registered=%d", moduleOk, buttonOk);

  startInstallThread();
  return true;
}

bool ElytraSwapMod::disable() {
  stopInstallThread();
  mTickHook.reset();
  mOpenHook.reset();
  mGetStackHook.reset();
  mSlotHook.reset();
  mHooksInstalled.store(false);
  reset();
  pl::modmenu::unregisterButton(ButtonId);
  pl::modmenu::unregisterModule(ModuleId);
  return true;
}

bool ElytraSwapMod::unload() { return true; }

void ElytraSwapMod::requestSwap() {
  if (!mActive.load()) return;
  const long long now = nowMs();
  if (now - mLastPressMs.load() < DebounceMs) return;
  mLastPressMs.store(now);
  mRequestedAtMs.store(now);
  mPressedAtMs = now;
  report::line("BUTTON pressed. Waiting for the inventory screen to open (hooks installed: %d)",
               mHooksInstalled.load() ? 1 : 0);
}

// --- hook installation --------------------------------------------------------

void ElytraSwapMod::startInstallThread() {
  stopInstallThread();
  mStopInstall.store(false);
  mInstallThread = std::thread([this] {
    // libminecraftpe.so may not be ready the moment enable() runs: retry for a minute.
    for (int i = 0; i < 120 && !mStopInstall.load(); ++i) {
      if (tryInstallHooks()) return;
      std::this_thread::sleep_for(std::chrono::milliseconds(500));
    }
    if (!mStopInstall.load()) {
      report::line("GAVE UP: could not install hooks (signatures not found for this game version)");
      getSelf().getLogger().info(
          "Elytra Swap: could not install hooks (signatures not found for this game version)");
    }
  });
}

void ElytraSwapMod::stopInstallThread() {
  mStopInstall.store(true);
  if (mInstallThread.joinable()) mInstallThread.join();
}

bool ElytraSwapMod::tryInstallHooks() {
  if (mHooksInstalled.load()) return true;

  game::Hooks hooks;
  std::string missing;
  if (!game::resolve(hooks, missing)) {
    static std::atomic<bool> reported{false};
    if (!reported.exchange(true)) {
      report::line("Signatures NOT all found yet (will retry for 60 s). Missing: %s", missing.c_str());
      report::line("Addresses: %s", hooks.detail.c_str());
    }
    return false;
  }
  report::line("All signatures found. Addresses: %s", hooks.detail.c_str());

  mTickHook = pl::memory::HookHandle(hooks.tick, reinterpret_cast<void *>(&ElytraSwapMod::tickDetour),
                                     reinterpret_cast<void **>(&gOriginalTick),
                                     pl::memory::HookPriority::Normal);
  mOpenHook = pl::memory::HookHandle(hooks.open, reinterpret_cast<void *>(&ElytraSwapMod::openDetour),
                                     reinterpret_cast<void **>(&gOriginalOpen),
                                     pl::memory::HookPriority::Normal);

  mGetStackHook = pl::memory::HookHandle(hooks.getStack, reinterpret_cast<void *>(&ElytraSwapMod::getStackDetour),
                                         reinterpret_cast<void **>(&gOriginalGetStack),
                                         pl::memory::HookPriority::Normal);
  mSlotHook = pl::memory::HookHandle(hooks.slotSelected, reinterpret_cast<void *>(&ElytraSwapMod::slotDetour),
                                     reinterpret_cast<void **>(&gOriginalSlot),
                                     pl::memory::HookPriority::Normal);

  if (!mTickHook.installed() || !mGetStackHook.installed()) {
    report::line("Hook install FAILED (tick=%d, open=%d, getStack=%d, slot=%d)",
                 mTickHook.installed() ? 1 : 0, mOpenHook.installed() ? 1 : 0,
                 mGetStackHook.installed() ? 1 : 0, mSlotHook.installed() ? 1 : 0);
    mTickHook.reset();
    mOpenHook.reset();
    mGetStackHook.reset();
    mSlotHook.reset();
    return false;
  }

  mHooksInstalled.store(true);
  report::line("Hooks installed (tick=1, open=%d, getStack=1, slot=%d). Ready: press the button.",
               mOpenHook.installed() ? 1 : 0, mSlotHook.installed() ? 1 : 0);
  getSelf().getLogger().info("Elytra Swap: ready (hooks installed)");
  return true;
}

// --- game thread --------------------------------------------------------------

void ElytraSwapMod::tickDetour(void *player) {
  if (gOriginalTick) gOriginalTick(player);

  static std::atomic<bool> first{true};
  if (first.exchange(false)) report::line("Tick hook is running (player=%p).", player);

  instance().onTick();
}

void *ElytraSwapMod::openDetour(void *a0, void *a1, void *a2, void *a3, void *a4, void *a5,
                                void *a6, void *a7) {
  static std::atomic<int> opens{0};
  if (opens.fetch_add(1) < 12) {
    report::line("Screen-open hook called (controller=%p, button pressed recently: %d)", a0,
                 instance().mRequestedAtMs.load() != 0 ? 1 : 0);
  }
  instance().onScreenOpened(a0);
  return gOriginalOpen ? gOriginalOpen(a0, a1, a2, a3, a4, a5, a6, a7) : nullptr;
}

const void *ElytraSwapMod::getStackDetour(void *controller, const std::string *collection, int index) {
  if (!game::inInternalCall()) {
    std::string name;
    const bool ok = collection && game::readStdString(collection, name);

    static std::atomic<int> logged{0};
    if (logged.fetch_add(1) < 15) {
      report::line("GetItemStack called (controller=%p, collection='%s', index=%d, button pending: %d)",
                   controller, ok ? name.c_str() : "?", index,
                   instance().mRequestedAtMs.load() != 0 ? 1 : 0);
    }
    if (ok && (name == "inventory_items" || name == "armor_items")) {
      instance().onScreenOpened(controller);
    }
  }
  return gOriginalGetStack ? gOriginalGetStack(controller, collection, index) : nullptr;
}

unsigned ElytraSwapMod::slotDetour(void *controller, const std::string *collection, int index) {
  if (!game::inInternalCall()) {
    std::string name;
    const bool ok = collection && game::readStdString(collection, name);
    static std::atomic<int> logged{0};
    if (logged.fetch_add(1) < 15) {
      report::line("Slot tapped by player (controller=%p, collection='%s', index=%d)", controller,
                   ok ? name.c_str() : "?", index);
    }
  }
  return gOriginalSlot ? gOriginalSlot(controller, collection, index) : 0;
}

void ElytraSwapMod::reset() {
  std::lock_guard<std::mutex> lock(mStateMutex);
  mStep = Step::Idle;
  mWait = 0;
  mActiveTicks = 0;
  mController = nullptr;
  mVtable = nullptr;
  mTarget = game::SlotRef{};
  mTriedTap = false;
  mWorn = game::Kind::Empty;
}

void ElytraSwapMod::abort(const char *reason) {
  report::line("STOPPED: %s", reason);
  getSelf().getLogger().info("Elytra Swap: stopped ({})", reason);
  // Caller holds no lock here; reset() takes it.
  reset();
}

void ElytraSwapMod::onScreenOpened(void *controller) {
  const long long requested = mRequestedAtMs.load();
  if (requested == 0) return;

  if (nowMs() - requested > RequestWindowMs) {
    report::line("A screen opened, but too late after the button press (%lld ms): ignored.",
                 nowMs() - requested);
    mRequestedAtMs.store(0);
    return;
  }

  std::lock_guard<std::mutex> lock(mStateMutex);
  if (mStep != Step::Idle || !controller) return;

  void *vtable = game::vtableOf(controller);
  if (!vtable) {
    report::line("Screen opened but its controller %p is unreadable: ignored.", controller);
    return;
  }

  report::line("Inventory screen opened %lld ms after the button press. controller=%p vtable=%p",
               nowMs() - requested, controller, vtable);
  mRequestedAtMs.store(0);
  mController = controller;
  mVtable = vtable;
  mStep = Step::Settle;
  mWait = 0;
  mActiveTicks = 0;
  mTriedTap = false;
  mTarget = game::SlotRef{};
}

void ElytraSwapMod::onTick() {
  // A button press that never produced a screen: say so in the report.
  {
    const long long requested = mRequestedAtMs.load();
    if (requested != 0 && nowMs() - requested > RequestWindowMs) {
      long long expected = requested;
      if (mRequestedAtMs.compare_exchange_strong(expected, 0)) {
        report::line("NO inventory screen opened within %lld ms after the button press.",
                     RequestWindowMs);
      }
    }
  }

  std::unique_lock<std::mutex> lock(mStateMutex);
  if (mStep == Step::Idle) return;

  if (++mActiveTicks > MaxActiveTicks) {
    lock.unlock();
    abort("timeout");
    return;
  }

  if (mStep == Step::CloseUp) {
    // Release the key; the screen closing by now is exactly what we wanted.
    sendGameKey(GameKeyE, false);
    lock.unlock();
    reset();
    return;
  }

  // The screen may have been closed (and its controller destroyed) meanwhile.
  if (game::vtableOf(mController) != mVtable) {
    lock.unlock();
    abort("screen closed");
    return;
  }

  void *ctrl = mController;

  // Several steps can run inside one game tick: a step either hands over to the
  // next one right away (continue) or waits for the next tick (return).
  for (;;) {
    switch (mStep) {
    case Step::Settle: {
      // Wait until the screen is filled in (right after opening it is empty).
      if (game::occupancy(ctrl) == 0 &&
          game::readKind(ctrl, "armor_items", 1) == game::Kind::Empty) {
        if (++mWait > SettleMaxTicks) {
          lock.unlock();
          abort("screen never filled in");
        }
        return;
      }

      game::Kind worn = game::Kind::Empty;
      const game::SlotRef target = game::chooseSwapSlot(ctrl, worn);
      mWorn = worn;
      mWait = 0;
      if (!target.valid()) {
        report::line("Nothing to swap with (worn chest item: %s).", kindName(worn));
        mStep = Step::Close;
        continue;
      }
      mTarget = target;
      if (worn == game::Kind::Empty) {
        game::quickMove(ctrl, target.collection, target.index);
        mStep = Step::Verify;
      } else {
        game::quickMove(ctrl, "armor_items", 1);
        mStep = Step::AfterUnequip;
      }
      continue;
    }

    case Step::AfterUnequip: {
      if (game::readKind(ctrl, "armor_items", 1) == game::Kind::Empty) {
        game::quickMove(ctrl, mTarget.collection, mTarget.index);
        mStep = Step::Verify;
        mWait = 0;
        continue;
      }
      if (++mWait > ActionMaxTicks) {
        report::line("Could not take off the worn %s (inventory full?).", kindName(mWorn));
        mStep = Step::Close;
        mWait = 0;
        continue;
      }
      return;
    }

    case Step::Verify: {
      const game::Kind now = game::readKind(ctrl, "armor_items", 1);
      if (now == mTarget.kind) {
        report::line("SWAP OK: now wearing %s (%lld ms after the press).", kindName(now),
                     nowMs() - mPressedAtMs);
        mStep = Step::Close;
        mWait = 0;
        continue;
      }
      if (++mWait > ActionMaxTicks) {
        report::line("SWAP FAILED: chest slot holds %s, wanted %s.", kindName(now),
                     kindName(mTarget.kind));
        mStep = Step::Close;
        mWait = 0;
        continue;
      }
      return;
    }

    case Step::Close: {
      const bool ok = sendGameKey(GameKeyE, true);
      if (!ok) {
        report::line("Could not close the inventory (key helper unavailable).");
        lock.unlock();
        reset();
        return;
      }
      mStep = Step::CloseUp;
      return;
    }

    default:
      return;
    }
  }
}
