#pragma once

#include <atomic>
#include <mutex>
#include <string>
#include <thread>

#include <pl/Mod.hpp>
#include <pl/memory/Hook.hpp>

#include "game/Game.hpp"

class ElytraSwapMod {
public:
  static ElytraSwapMod &instance();

  ElytraSwapMod();

  [[nodiscard]] ll::mod::NativeMod &getSelf() const { return mSelf; }

  bool load();
  bool enable();
  bool disable();
  bool unload();

  // Called from the on-screen button (Android UI thread). Only sets a flag.
  void requestSwap();

  // Game hooks.
  static void tickDetour(void *player);
  static void *openDetour(void *a0, void *a1, void *a2, void *a3, void *a4, void *a5,
                          void *a6, void *a7);

private:
  enum class Step { Idle, Settle, AfterUnequip, AfterTap, Verify };

  void onTick();
  void onScreenOpened(void *controller);
  void reset();
  void abort(const char *reason);

  bool tryInstallHooks();
  void startInstallThread();
  void stopInstallThread();

  ll::mod::NativeMod &mSelf;

  pl::memory::HookHandle mTickHook;
  pl::memory::HookHandle mOpenHook;
  std::thread mInstallThread;
  std::atomic<bool> mStopInstall{false};
  std::atomic<bool> mHooksInstalled{false};

  std::atomic<bool> mActive{true};
  std::atomic<long long> mRequestedAtMs{0};
  std::atomic<long long> mLastPressMs{0};

  // Everything below is protected by mStateMutex (touched by the open hook and
  // the tick hook).
  std::mutex mStateMutex;
  Step mStep = Step::Idle;
  int mWait = 0;
  int mActiveTicks = 0;
  void *mController = nullptr;
  void *mVtable = nullptr;
  elytra::game::SlotRef mTarget;
  bool mTriedTap = false;
};
