#include "game/Game.hpp"

#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <mutex>

#include <dlfcn.h>
#include <unistd.h>

#include <pl/memory/Signature.hpp>

#include "Report.hpp"

namespace firework::game {
namespace {

constexpr const char *kModule = "libminecraftpe.so";

// ClientInstance::getLocalPlayer (BedrockTools signature, verified on 1.26.50: matches
// once). This mod hooks THIS function on purpose, not the per-tick function that
// Elytra Swap hooks, so the two mods never touch the same piece of game code.
constexpr const char *kSigGetLocalPlayer =
    "? ? ? D1 ? ? ? A9 ? ? ? F9 ? ? ? 91 53 D0 3B D5 E8 03 00 AA ? ? ? 91 ? ? ? F9 ? ? ? 91 ? ? ? F8 ? ? ? 95 ? ? ? 91 ? ? ? 95 ? ? ? 36 ? ? ? 91 ? ? ? 52 ? ? ? 94";

// Addresses inside the .so file (1.26.50.4). base = runtime address - file address.
constexpr std::uintptr_t kHookFileAddr = 0x9807f90;
constexpr std::uintptr_t kVtLocalPlayer = 0x12d08918;
constexpr std::uintptr_t kVtPlayerInventory = 0x130348f0;
constexpr std::uintptr_t kVtInventory = 0x13033ee8;

constexpr std::size_t kOffPlayerInventory = 0x570;
constexpr std::size_t kOffSelected = 0x10;
constexpr std::size_t kOffInventory = 0xB8;
constexpr std::size_t kOffItemsBegin = 0x140;
constexpr std::size_t kOffItemsEnd = 0x148;
constexpr std::size_t kStackSize = 0x98;
constexpr std::size_t kSlots = 36;

// ItemStack layout (BedrockTools, verified by the elytra mod on this version).
constexpr std::size_t kStackItemCounter = 0x8;
constexpr std::size_t kStackCount = 0x22;
constexpr std::size_t kStackValid = 0x23;
constexpr std::size_t kItemGetDescriptionIdVtableIndex = 5;

using GetDescriptionIdFn = const void *(*)(const void *item);

std::uintptr_t gBase = 0;

struct Pipe {
  int fds[2] = {-1, -1};
  Pipe() {
    if (pipe(fds) != 0) fds[0] = fds[1] = -1;
  }
};
std::mutex gPipeMutex;

template <class T>
bool readAt(const void *base, std::size_t offset, T &out) {
  return safeRead(static_cast<const std::byte *>(base) + offset, &out, sizeof(T));
}

bool decodeString(const void *p, std::string &out) {
  unsigned char raw[24];
  if (!safeRead(p, raw, sizeof(raw))) return false;

  std::string text;
  if ((raw[0] & 1) == 0) {
    const std::size_t n = raw[0] >> 1;
    if (n == 0 || n > 22) return false;
    text.assign(reinterpret_cast<const char *>(raw + 1), n);
  } else {
    std::size_t n = 0;
    const char *data = nullptr;
    std::memcpy(&n, raw + 8, sizeof(n));
    std::memcpy(&data, raw + 16, sizeof(data));
    if (n == 0 || n > 128 || !data) return false;
    char chunk[64];
    for (std::size_t done = 0; done < n;) {
      const std::size_t part = (n - done) < sizeof(chunk) ? (n - done) : sizeof(chunk);
      if (!safeRead(data + done, chunk, part)) return false;
      text.append(chunk, part);
      done += part;
    }
  }
  for (const char c : text)
    if (c < 0x20 || c > 0x7e) return false;
  out = std::move(text);
  return true;
}

bool insideGame(std::uintptr_t fn) {
  Dl_info info{};
  if (!dladdr(reinterpret_cast<void *>(fn), &info) || !info.dli_fname) return false;
  return std::strstr(info.dli_fname, "libminecraftpe") != nullptr;
}

// Reads the item name of a stack. Returns "" when the slot is empty or unreadable.
bool stackInfo(const void *stack, std::string &name, int &count) {
  name.clear();
  count = 0;
  std::uint8_t valid = 0, cnt = 0;
  if (!readAt(stack, kStackValid, valid) || !readAt(stack, kStackCount, cnt)) return false;
  if (!valid || cnt == 0) return true; // genuinely empty
  count = cnt;

  const void *counter = nullptr;
  const void *item = nullptr;
  const std::uintptr_t *vtable = nullptr;
  std::uintptr_t fn = 0;
  if (!readAt(stack, kStackItemCounter, counter) || !counter) return false;
  if (!safeRead(counter, &item, sizeof(item)) || !item) return false;
  if (!safeRead(item, &vtable, sizeof(vtable)) || !vtable) return false;
  if (!safeRead(vtable + kItemGetDescriptionIdVtableIndex, &fn, sizeof(fn)) || !fn) return false;
  if (!insideGame(fn)) return false;
  const void *str = reinterpret_cast<GetDescriptionIdFn>(fn)(item);
  return decodeString(str, name);
}

bool hasVtable(const void *object, std::uintptr_t vtableFileAddr) {
  std::uintptr_t vt = 0;
  return object && readAt(object, 0, vt) && vt == gBase + vtableFileAddr;
}

// --- launcher key helper -----------------------------------------------------

using InitFn = unsigned char (*)(void *, void *);
using KeyFn = void (*)(void *, void *, int, unsigned char);
using MouseFn = void (*)(void *, void *, int, unsigned char);

KeyFn gKey = nullptr;
MouseFn gMouse = nullptr;
bool gHelperTried = false;

void loadHelper() {
  if (gHelperTried) return;
  gHelperTried = true;
  void *lib = dlopen("libinbuiltmods.so", RTLD_NOW | RTLD_NOLOAD);
  if (!lib) lib = dlopen("libinbuiltmods.so", RTLD_NOW);
  InitFn init = nullptr;
  if (lib) {
    init = reinterpret_cast<InitFn>(dlsym(
        lib, "Java_org_levimc_launcher_core_mods_inbuilt_nativemod_MoreButtonsMod_nativeInit"));
    gKey = reinterpret_cast<KeyFn>(dlsym(
        lib, "Java_org_levimc_launcher_core_mods_inbuilt_nativemod_MoreButtonsMod_nativeSendKey"));
    gMouse = reinterpret_cast<MouseFn>(dlsym(
        lib, "Java_org_levimc_launcher_core_mods_inbuilt_nativemod_PojavControlsMod_nativeSendMouseButton"));
  }
  elytra::report::line("Input helper: lib=%p init=%p key=%p mouse=%p", lib,
                       reinterpret_cast<void *>(init), reinterpret_cast<void *>(gKey),
                       reinterpret_cast<void *>(gMouse));
  if (init) init(nullptr, nullptr);
}

} // namespace

bool safeRead(const void *src, void *dst, std::size_t size) {
  static Pipe pipeHolder;
  if (!src || !dst || size == 0 || size > 64) return false;
  if (pipeHolder.fds[0] < 0) return false;

  std::lock_guard<std::mutex> lock(gPipeMutex);
  const ssize_t written = write(pipeHolder.fds[1], src, size);
  if (written != static_cast<ssize_t>(size)) {
    if (written > 0) {
      std::byte tmp[64];
      (void)read(pipeHolder.fds[0], tmp, static_cast<std::size_t>(written));
    }
    return false;
  }
  return read(pipeHolder.fds[0], dst, size) == static_cast<ssize_t>(size);
}

bool resolveHookTarget(void *&target, std::string &detail) {
  const std::uintptr_t addr = pl::memory::resolveSignature(kSigGetLocalPlayer, kModule);
  char buf[96];
  std::snprintf(buf, sizeof(buf), "GetLocalPlayer=0x%llx", static_cast<unsigned long long>(addr));
  detail = buf;
  if (!addr) return false;
  target = reinterpret_cast<void *>(addr);
  gBase = addr - kHookFileAddr;
  return true;
}

bool readState(void *player, State &out) {
  out = State{};
  if (!gBase) {
    out.why = "no base";
    return false;
  }
  if (!hasVtable(player, kVtLocalPlayer)) {
    out.why = "not the local player";
    return false;
  }

  const void *pinv = nullptr;
  if (!readAt(player, kOffPlayerInventory, pinv) || !hasVtable(pinv, kVtPlayerInventory)) {
    out.why = "PlayerInventory not where expected";
    return false;
  }
  std::int32_t selected = -1;
  readAt(pinv, kOffSelected, selected);

  const void *inv = nullptr;
  if (!readAt(pinv, kOffInventory, inv) || !hasVtable(inv, kVtInventory)) {
    out.why = "Inventory not where expected";
    return false;
  }
  std::uintptr_t begin = 0, end = 0;
  if (!readAt(inv, kOffItemsBegin, begin) || !readAt(inv, kOffItemsEnd, end) || !begin ||
      end - begin != kSlots * kStackSize) {
    out.why = "item list has an unexpected size";
    return false;
  }

  out.selected = selected;
  for (int i = 0; i < 9; ++i) {
    const void *stack = reinterpret_cast<const void *>(begin + i * kStackSize);
    if (!stackInfo(stack, out.name[i], out.count[i])) {
      out.why = "a hotbar stack is unreadable";
      return false;
    }
  }
  out.ok = true;
  out.why = "ok";
  return true;
}

bool isFirework(const std::string &name) { return name.find("firework") != std::string::npos; }

bool sendKey(int bedrockKey, bool down) {
  loadHelper();
  if (!gKey) return false;
  gKey(nullptr, nullptr, bedrockKey, down ? 1 : 0);
  return true;
}

bool sendMouse(int androidButton, bool down) {
  loadHelper();
  if (!gMouse) return false;
  gMouse(nullptr, nullptr, androidButton, down ? 1 : 0);
  return true;
}

} // namespace firework::game
