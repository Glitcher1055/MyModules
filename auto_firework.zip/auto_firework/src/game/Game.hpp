#pragma once

// Everything that touches Minecraft internals lives here.
//
// Memory layout (found by reading libminecraftpe.so 1.26.50.4, checked at run time:
// every pointer is verified against the game's own class tables before it is used):
//   LocalPlayer + 0x570          -> PlayerInventory
//   PlayerInventory + 0x10       -> int, selected hotbar slot (0..8)
//   PlayerInventory + 0xB8       -> Inventory
//   Inventory + 0x140 / + 0x148  -> begin / end of the item list (36 stacks of 0x98 bytes)

#include <string>

namespace firework::game {

struct State {
  bool ok = false;
  const char *why = "not read";
  int selected = -1;
  std::string name[9];  // description id of each hotbar slot ("" = empty)
  int count[9] = {};    // stack size of each hotbar slot
};

// Finds the per-tick player function. `detail` receives a printable address.
bool resolveTick(void *&tick, std::string &detail);

// Reads the hotbar and the selected slot of the local player. `player` is the
// object the tick function was called for; anything else is refused.
bool readState(void *player, State &out);

bool isFirework(const std::string &name);

// Presses a key / mouse button in the game through the launcher's own native
// helper (the one its on-screen buttons use). Keys use Windows codes: '1'..'9' are
// 49..57. Mouse buttons use Android codes: 1 = left, 2 = right.
bool sendKey(int bedrockKey, bool down);
bool sendMouse(int androidButton, bool down);

// Crash-safe read: returns false instead of crashing on a bad address.
bool safeRead(const void *src, void *dst, std::size_t size);

} // namespace firework::game
