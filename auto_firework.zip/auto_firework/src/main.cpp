// Entry point. PL_REGISTER_MOD must be used exactly once, here.
#include <pl/Mod.hpp>

#include "FireworkMod.hpp"

PL_REGISTER_MOD(FireworkMod, FireworkMod::instance())
