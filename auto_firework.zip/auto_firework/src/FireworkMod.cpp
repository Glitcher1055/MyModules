#include "FireworkMod.hpp"

#include <chrono>
#include <cstdlib>
#include <fstream>
#include <span>
#include <string>
#include <string_view>

#include <pl/ModMenu.hpp>

#include "Icon.hpp"
#include "Report.hpp"

namespace game = firework::game;
namespace report = elytra::report;

namespace {

constexpr const char *ModuleId = "auto_firework.module";
constexpr const char *ButtonId = "auto_firework.use";

constexpr long long DebounceMs = 250;
constexpr long long RequestWindowMs = 1500;
constexpr int WaitMaxTicks = 4;   // how long to wait for the game to react to a key

constexpr int KeyDigit1 = 49;     // Windows code of '1'
constexpr int MouseRight = 2;     // Android BUTTON_SECONDARY

using TickFn = void (*)(void *);
TickFn gOriginalTick = nullptr;

long long nowMs() {
  using namespace std::chrono;
  return duration_cast<milliseconds>(steady_clock::now().time_since_epoch()).count();
}

int clampOpacity(int percent) {
  int level = (percent + 5) / 10 * 10;
  if (level < 10) level = 10;
  if (level > 100) level = 100;
  return level;
}

} // namespace

FireworkMod &FireworkMod::instance() {
  static FireworkMod inst;
  return inst;
}

FireworkMod::FireworkMod() : mSelf(*ll::mod::NativeMod::current()) {}

bool FireworkMod::load() {
  auto &self = getSelf();
  report::init(self.getDataDir());
  report::line("Auto Firework 0.1.0. Loaded as '%s'.", self.getName().c_str());
  report::line("Report file: %s", report::primaryPath().c_str());
  return true;
}

bool FireworkMod::registerButton(int opacityPercent) {
  const auto &icon = kButtonIcons[clampOpacity(opacityPercent) / 10 - 1];
  return pl::modmenu::ButtonBuilder(ButtonId, "Auto Firework")
      .modId(getSelf().getId())
      .moduleId(ModuleId)
      .label("")
      .pngIcon(std::span<const unsigned char>(icon.data, icon.size))
      .sizeScale(1.0f, 1.0f)
      // The picture already is the whole button: make the launcher's own
      // background and border (almost) invisible so nothing shows behind it.
      .styleColors(0x01000000u, 0x01000000u, 0x01000000u)
      .behavior(pl::modmenu::ButtonBehavior::Click)
      .onEvent([](std::string_view, pl::modmenu::ButtonEvent event, float) {
        if (event == pl::modmenu::ButtonEvent::Click || event == pl::modmenu::ButtonEvent::Down) {
          instance().requestUse();
        }
      })
      .registerButton();
}

void FireworkMod::loadOpacity() {
  std::ifstream in(getSelf().getDataDir() / "opacity.txt");
  int value = 100;
  if (in >> value) mOpacity.store(clampOpacity(value));
}

void FireworkMod::setOpacity(int percent) {
  const int level = clampOpacity(percent);
  if (level == mOpacity.load()) return;
  mOpacity.store(level);
  {
    std::ofstream out(getSelf().getDataDir() / "opacity.txt", std::ios::trunc);
    out << level;
  }
  pl::modmenu::unregisterButton(ButtonId);
  const bool ok = registerButton(level);
  report::line("Opacity set to %d%% (button re-registered: %d)", level, ok);
}

bool FireworkMod::enable() {
  auto &self = getSelf();
  loadOpacity();

  const bool moduleOk =
      pl::modmenu::ModuleBuilder(ModuleId, "Auto Firework")
          .modId(self.getId())
          .description("One button: take the firework from the hotbar, use it, switch back.")
          .defaultEnabled(true)
          .onToggle([](std::string_view, bool enabled) { instance().mActive.store(enabled); })
          .config("opacity", "Button opacity (%)", pl::modmenu::ConfigType::SliderInt,
                  std::to_string(mOpacity.load()), "10", "100")
          .onConfigChanged([](std::string_view, std::string_view key, std::string_view value) {
            if (key == "opacity") instance().setOpacity(std::atoi(std::string(value).c_str()));
          })
          .registerModule();
  const bool buttonOk = registerButton(mOpacity.load());
  report::line("enable(): menu module registered=%d, button registered=%d", moduleOk, buttonOk);

  startInstallThread();
  return true;
}

bool FireworkMod::disable() {
  stopInstallThread();
  mTickHook.reset();
  mHookInstalled.store(false);
  pl::modmenu::unregisterButton(ButtonId);
  pl::modmenu::unregisterModule(ModuleId);
  return true;
}

bool FireworkMod::unload() { return true; }

void FireworkMod::requestUse() {
  if (!mActive.load()) return;
  const long long now = nowMs();
  if (now - mLastPressMs.load() < DebounceMs) return;
  mLastPressMs.store(now);
  mRequestedAtMs.store(now);
}

// --- hook installation --------------------------------------------------------

void FireworkMod::startInstallThread() {
  stopInstallThread();
  mStopInstall.store(false);
  mInstallThread = std::thread([this] {
    for (int i = 0; i < 120 && !mStopInstall.load(); ++i) {
      if (tryInstallHook()) return;
      std::this_thread::sleep_for(std::chrono::milliseconds(500));
    }
    if (!mStopInstall.load()) report::line("GAVE UP: could not find the game's tick function.");
  });
}

void FireworkMod::stopInstallThread() {
  mStopInstall.store(true);
  if (mInstallThread.joinable()) mInstallThread.join();
}

bool FireworkMod::tryInstallHook() {
  if (mHookInstalled.load()) return true;

  void *tick = nullptr;
  std::string detail;
  if (!game::resolveTick(tick, detail)) return false;
  report::line("Found %s", detail.c_str());

  mTickHook = pl::memory::HookHandle(tick, reinterpret_cast<void *>(&FireworkMod::tickDetour),
                                     reinterpret_cast<void **>(&gOriginalTick),
                                     pl::memory::HookPriority::Normal);
  if (!mTickHook.installed()) {
    report::line("Hook install FAILED");
    mTickHook.reset();
    return false;
  }
  mHookInstalled.store(true);
  report::line("Hook installed. Ready: put a firework in the hotbar and press the button.");
  return true;
}

// --- game thread --------------------------------------------------------------

void FireworkMod::tickDetour(void *player) {
  if (gOriginalTick) gOriginalTick(player);
  instance().onTick(player);
}

void FireworkMod::finish(const char *how) {
  report::line("%s (%lld ms after the press)", how, nowMs() - mStartedAtMs);
  mStep = Step::Idle;
  mWait = 0;
}

void FireworkMod::onTick(void *player) {
  // Nothing to do (the common case): one atomic read and one comparison.
  const long long requested = mRequestedAtMs.load();
  if (mStep == Step::Idle) {
    if (requested == 0) return;
    mRequestedAtMs.store(0);
    if (nowMs() - requested > RequestWindowMs) return;

    game::State st;
    if (!game::readState(player, st)) {
      // Not the local player (or the layout is not what we expect): try again next tick
      // unless it is a real layout problem, which we report once per press.
      if (std::string_view(st.why) != "not the local player") {
        report::line("Cannot read the hotbar: %s", st.why);
      } else {
        mRequestedAtMs.store(requested); // keep waiting for the local player's tick
      }
      return;
    }

    std::string hot;
    for (int i = 0; i < 9; ++i) {
      hot += st.name[i].empty() ? "-" : st.name[i];
      if (st.count[i] > 1) hot += "x" + std::to_string(st.count[i]);
      hot += (i == 8 ? "" : ", ");
    }
    report::line("PRESS: selected slot=%d. Hotbar: %s", st.selected, hot.c_str());

    int slot = -1;
    if (st.selected >= 0 && st.selected < 9 && game::isFirework(st.name[st.selected])) {
      slot = st.selected;
    } else {
      for (int i = 0; i < 9; ++i) {
        if (game::isFirework(st.name[i])) {
          slot = i;
          break;
        }
      }
    }
    if (slot < 0) {
      report::line("No firework in the hotbar.");
      return;
    }

    mSlot = slot;
    mPrevSlot = (st.selected >= 0 && st.selected < 9) ? st.selected : slot;
    mCountBefore = st.count[slot];
    mStartedAtMs = requested;
    mWait = 0;
    mStep = (mSlot == mPrevSlot) ? Step::UseDown : Step::SelDown;
    // fall through to the state machine below in the same tick
  }

  auto selected = [&]() {
    game::State s;
    return game::readState(player, s) ? s.selected : -1;
  };

  switch (mStep) {
  case Step::SelDown:
    if (!game::sendKey(KeyDigit1 + mSlot, true)) {
      finish("FAILED: the launcher's key helper is not available");
      return;
    }
    mStep = Step::SelUp;
    return;

  case Step::SelUp:
    game::sendKey(KeyDigit1 + mSlot, false);
    mWait = 0;
    mStep = Step::WaitSel;
    return;

  case Step::WaitSel:
    if (selected() == mSlot || ++mWait > WaitMaxTicks) {
      if (selected() != mSlot) report::line("Selecting slot %d did not take effect (still %d).", mSlot, selected());
      mStep = Step::UseDown;
      [[fallthrough]];
    } else {
      return;
    }

  case Step::UseDown:
    if (!game::sendMouse(MouseRight, true)) {
      finish("FAILED: the launcher's mouse helper is not available");
      return;
    }
    mStep = Step::UseUp;
    return;

  case Step::UseUp:
    game::sendMouse(MouseRight, false);
    mWait = 0;
    mStep = Step::UseWait;
    return;

  case Step::UseWait: {
    if (++mWait < 2) return;
    game::State s;
    if (game::readState(player, s)) {
      report::line("After use: firework count %d -> %d", mCountBefore, s.count[mSlot]);
    }
    if (mSlot == mPrevSlot) {
      finish("DONE");
      return;
    }
    mStep = Step::BackDown;
    [[fallthrough]];
  }

  case Step::BackDown:
    game::sendKey(KeyDigit1 + mPrevSlot, true);
    mStep = Step::BackUp;
    return;

  case Step::BackUp:
    game::sendKey(KeyDigit1 + mPrevSlot, false);
    mWait = 0;
    mStep = Step::WaitBack;
    return;

  case Step::WaitBack:
    if (selected() == mPrevSlot || ++mWait > WaitMaxTicks) {
      report::line("Back on slot %d: %s", mPrevSlot, selected() == mPrevSlot ? "yes" : "NO");
      finish("DONE");
    }
    return;

  default:
    return;
  }
}
