#pragma once

#include <atomic>
#include <mutex>
#include <string>
#include <thread>

#include <pl/Mod.hpp>
#include <pl/memory/Hook.hpp>

#include "game/Game.hpp"

class FireworkMod {
public:
  static FireworkMod &instance();

  FireworkMod();

  [[nodiscard]] ll::mod::NativeMod &getSelf() const { return mSelf; }

  bool load();
  bool enable();
  bool disable();
  bool unload();

  // Called from the on-screen button (Android UI thread). Only sets a flag.
  void requestUse();

  static void *playerDetour(void *clientInstance);

private:
  enum class Step { Idle, SelDown, SelUp, WaitSel, UseDown, UseUp, UseWait, BackDown, BackUp, WaitBack };

  void onPlayer(void *player);
  void finish(const char *how);

  bool registerButton(int opacityPercent);
  void loadOpacity();
  void setOpacity(int percent);

  bool tryInstallHook();
  void startInstallThread();
  void stopInstallThread();

  ll::mod::NativeMod &mSelf;

  pl::memory::HookHandle mTickHook;
  std::thread mInstallThread;
  std::atomic<bool> mStopInstall{false};
  std::atomic<bool> mHookInstalled{false};

  std::atomic<bool> mActive{true};
  std::atomic<int> mOpacity{100};
  std::atomic<long long> mRequestedAtMs{0};
  std::atomic<bool> mBusy{false};
  std::atomic<long long> mLastPressMs{0};

  // The hooked function can be called from more than one thread: the state below
  // is protected by mStateMutex (taken with try_lock, so the game never waits).
  std::mutex mStateMutex;
  long long mNextAtMs = 0;
  Step mStep = Step::Idle;
  int mWait = 0;
  int mSlot = 0;       // hotbar slot that holds the firework
  int mPrevSlot = 0;   // slot that was selected before
  int mCountBefore = 0;
  long long mStartedAtMs = 0;
};
