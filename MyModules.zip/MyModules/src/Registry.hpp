#pragma once

#include "Module.hpp"
#include <memory>
#include <string_view>
#include <vector>

class Registry {
public:
    static Registry& get();
    const std::vector<std::unique_ptr<Module>>& modules() const { return m_modules; }
    Module* find(std::string_view id) const;
    void registerAll();   // сюда добавляются новые модули

private:
    std::vector<std::unique_ptr<Module>> m_modules;
};
