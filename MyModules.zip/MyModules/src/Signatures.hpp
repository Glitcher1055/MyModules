#pragma once

namespace sig {

enum Id { NormalTick, GameModeUseItem, SurvivalModeUseItem, GameModeStartDestroyBlock, SurvivalModeStartDestroyBlock, GameModeStartBuildBlock, SurvivalModeStartBuildBlock, Count };
extern const char* const Patterns[Count];

}
