#include "GameHooks.hpp"
#include "Signatures.hpp"

#include <cstdint>
#include <cstring>
#include <dlfcn.h>
#include <fcntl.h>
#include <mutex>
#include <pl/memory/Hook.hpp>
#include <pl/memory/Signature.hpp>
#include <string>
#include <unistd.h>
#include <vector>

namespace gh {
namespace {

using TickFn = void (*)(void*);
using UseItemFn = bool (*)(void*, void*);
using StartDestroyFn = bool (*)(void*, const void*, std::uint8_t, bool*);
using StartBuildFn = void (*)(void*, const void*, std::uint8_t);

State g;
std::mutex installMutex;
void (*tickCallback)() = nullptr;
thread_local bool inInstall = false;

TickFn tickOrig = nullptr;
UseItemFn gmUseOrig = nullptr, svUseOrig = nullptr;
StartDestroyFn gmDestroyOrig = nullptr, svDestroyOrig = nullptr;
StartBuildFn gmBuildOrig = nullptr, svBuildOrig = nullptr;

void remember(void* gameMode, bool survival) {
    if (!gameMode) return;
    g.gameMode = gameMode;
    g.survival = survival;
}

void tickDetour(void* actor) {
    g.player = actor;
    if (tickOrig) tickOrig(actor);
    if (tickCallback) tickCallback();
}
bool gmUseDetour(void* gm, void* item) { remember(gm, false); return gmUseOrig ? gmUseOrig(gm, item) : false; }
bool svUseDetour(void* gm, void* item) { remember(gm, true); return svUseOrig ? svUseOrig(gm, item) : false; }
bool gmDestroyDetour(void* gm, const void* p, std::uint8_t f, bool* d) { remember(gm, false); return gmDestroyOrig ? gmDestroyOrig(gm, p, f, d) : false; }
bool svDestroyDetour(void* gm, const void* p, std::uint8_t f, bool* d) { remember(gm, true); return svDestroyOrig ? svDestroyOrig(gm, p, f, d) : false; }
void gmBuildDetour(void* gm, const void* p, std::uint8_t f) { remember(gm, false); if (gmBuildOrig) gmBuildOrig(gm, p, f); }
void svBuildDetour(void* gm, const void* p, std::uint8_t f) { remember(gm, true); if (svBuildOrig) svBuildOrig(gm, p, f); }

bool hookAt(std::uintptr_t address, void* detour, void** original) {
    if (!address) return false;
    ++g.found;
    if (pl::memory::hook(reinterpret_cast<void*>(address), detour, original) != 0) return false;
    ++g.hooked;
    return true;
}

// --- ожидание загрузки libminecraftpe.so ---
void* (*dlopenOrig)(const char*, int) = nullptr;

void* dlopenDetour(const char* filename, int flags) {
    void* handle = dlopenOrig ? dlopenOrig(filename, flags) : nullptr;
    if (handle && filename && std::strstr(filename, "libminecraftpe.so") && !inInstall) install();
    return handle;
}

bool gameProcess() {
    int fd = open("/proc/self/cmdline", O_RDONLY);
    if (fd < 0) return false;
    char cmd[256]{};
    const auto n = read(fd, cmd, sizeof(cmd) - 1);
    close(fd);
    if (n <= 0) return false;
    return std::strcmp(cmd, "org.levimc.launcher") == 0 || std::strcmp(cmd, "org.levimc.launcher:minecraft") == 0 ||
           std::strcmp(cmd, "com.mojang.minecraftpe") == 0;
}

}

State& state() { return g; }
void setTickCallback(void (*cb)()) { tickCallback = cb; }

bool useItemAvailable(bool survival) { return (survival ? svUseOrig : gmUseOrig) != nullptr; }

bool callUseItem(void* gameMode, bool survival, void* itemStack) {
    UseItemFn fn = survival ? svUseOrig : gmUseOrig;
    return fn && gameMode ? fn(gameMode, itemStack) : false;
}

bool install() {
    std::lock_guard lock(installMutex);
    if (g.installed) return true;
    void* mc = dlopen("libminecraftpe.so", RTLD_NOW | RTLD_NOLOAD);
    if (!mc) return false;
    dlclose(mc);

    inInstall = true;
    std::vector<std::string> patterns;
    for (int i = 0; i < sig::Count; ++i) patterns.emplace_back(sig::Patterns[i]);
    const auto resolved = pl::memory::resolveSignatures(patterns, "libminecraftpe.so");
    inInstall = false;

    auto addr = [&](int id) -> std::uintptr_t {
        const auto it = resolved.find(patterns[id]);
        return it == resolved.end() ? 0 : it->second;
    };
    hookAt(addr(sig::NormalTick), reinterpret_cast<void*>(tickDetour), reinterpret_cast<void**>(&tickOrig));
    hookAt(addr(sig::GameModeUseItem), reinterpret_cast<void*>(gmUseDetour), reinterpret_cast<void**>(&gmUseOrig));
    hookAt(addr(sig::SurvivalModeUseItem), reinterpret_cast<void*>(svUseDetour), reinterpret_cast<void**>(&svUseOrig));
    hookAt(addr(sig::GameModeStartDestroyBlock), reinterpret_cast<void*>(gmDestroyDetour), reinterpret_cast<void**>(&gmDestroyOrig));
    hookAt(addr(sig::SurvivalModeStartDestroyBlock), reinterpret_cast<void*>(svDestroyDetour), reinterpret_cast<void**>(&svDestroyOrig));
    hookAt(addr(sig::GameModeStartBuildBlock), reinterpret_cast<void*>(gmBuildDetour), reinterpret_cast<void**>(&gmBuildOrig));
    hookAt(addr(sig::SurvivalModeStartBuildBlock), reinterpret_cast<void*>(svBuildDetour), reinterpret_cast<void**>(&svBuildOrig));
    g.installed = true;
    return true;
}

void start() {
    if (!gameProcess()) return;
    if (install()) return;
    // libminecraftpe.so ещё не загружена — ловим её загрузку через dlopen
    void* libdl = dlopen("libdl.so", RTLD_NOW | RTLD_NOLOAD);
    if (!libdl) libdl = dlopen("libdl.so", RTLD_NOW);
    if (!libdl) return;
    void* sym = dlsym(libdl, "dlopen");
    if (sym && !dlopenOrig)
        pl::memory::hook(sym, reinterpret_cast<void*>(dlopenDetour), reinterpret_cast<void**>(&dlopenOrig));
    dlclose(libdl);
}

}
