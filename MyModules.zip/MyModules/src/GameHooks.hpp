#pragma once

#include <string>

// Собственные хуки игры (без BedrockTools).
namespace gh {

struct State {
    void* player = nullptr;      // локальный игрок (из тика)
    void* gameMode = nullptr;    // GameMode (после первого действия: удар/блок/предмет)
    bool survival = false;
    int hooked = 0;              // сколько хуков установлено
    int found = 0;               // сколько сигнатур найдено
    bool installed = false;
    // диагностика
    bool gameProc = false;       // процесс игры (а не UI лаунчера)
    bool libLoaded = false;      // libminecraftpe.so загружена
    bool dlHooked = false;       // повесили ожидание загрузки библиотеки
    int installCalls = 0;
};

State& state();
bool install();                         // найти сигнатуры и поставить хуки (один раз)
void setTickCallback(void (*cb)());     // вызывается каждый тик игрока
bool callUseItem(void* gameMode, bool survival, void* itemStack);
bool useItemAvailable(bool survival);

// Вызывать из load()/enable(): ждёт загрузки libminecraftpe.so и ставит хуки.
void start();

}
