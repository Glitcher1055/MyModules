#include "Registry.hpp"
#include "modules/elytraswap.hpp"

Registry& Registry::get() {
    static Registry r;
    return r;
}

Module* Registry::find(std::string_view id) const {
    for (auto& m : m_modules) if (m->id == id) return m.get();
    return nullptr;
}

void Registry::registerAll() {
    if (!m_modules.empty()) return;
    m_modules.push_back(std::make_unique<ElytraSwapModule>());
    // m_modules.push_back(std::make_unique<ТвойНовыйМодуль>());
    for (auto& m : m_modules) m->onInit();
}
