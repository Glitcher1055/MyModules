#pragma once

#include "Module.hpp"

#include <string>

#include <bedrocktools/BedrockTools.hpp>

class ElytraSwapModule : public Module {
public:
    ElytraSwapModule();
    void onInit() override;
    void onKeybind(std::string_view key, bool isDown) override;

private:
    using UseItemFn = bool (*)(void*, void*);

    bool ensureRuntime();   // подключение к BedrockTools (он должен быть установлен и включён)
    void registerButton();
    bool swap();
    bool fail(const char* reason);

    const bedrocktools::api::ApiV1* m_api = nullptr;
    bedrocktools::events::RuntimeListener<bedrocktools::events::LocalPlayerTickEvent> m_tick;
    bedrocktools::events::RuntimeListener<bedrocktools::events::GameModeActionEvent> m_action;

    bedrocktools::sdk::Player* m_player = nullptr;
    void* m_gameMode = nullptr;
    bedrocktools::events::GameModeType m_modeKind = bedrocktools::events::GameModeType::GameMode;
    UseItemFn m_gameModeUseItem = nullptr;
    UseItemFn m_survivalModeUseItem = nullptr;
    bool m_swapping = false;
    bool m_dirty = false;
    std::string m_status = "ready";
};
