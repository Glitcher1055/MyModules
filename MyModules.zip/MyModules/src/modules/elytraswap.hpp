#pragma once

#include "Module.hpp"

#include <string>

class ElytraSwapModule : public Module {
public:
    ElytraSwapModule();
    void onInit() override;
    void onKeybind(std::string_view key, bool isDown) override;

    void onTick();   // вызывается каждый тик игрока

private:
    void registerButton();
    std::string labelText() const;
    void startRefreshThread();
    bool swap();
    bool fail(const char* reason);

    bool m_dirty = false;
    bool m_pending = false;   // свап отложен до первого действия в игре
    bool m_swapping = false;
    int m_eventCount = 0;
    std::string m_lastEvent = "-";
    long long m_lastTriggerMs = 0;
    std::string m_status = "ready";
    std::string m_shownText;
};
