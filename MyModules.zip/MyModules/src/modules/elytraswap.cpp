#include "elytraswap.hpp"
#include "elytraswap_icon.hpp"

#include "GameHooks.hpp"
#include <bedrocktools/sdk/Offsets.hpp>
#include <bedrocktools/sdk/input/MoveInput.hpp>

#include <pl/ModMenu.hpp>

#include <chrono>
#include <cstddef>
#include <span>
#include <cstdint>
#include <string>

namespace {

using namespace bedrocktools::sdk::offsets::Inventory;
namespace bt = bedrocktools;

ElytraSwapModule* gInstance = nullptr;

constexpr const char* ButtonId = "mymodules.ElytraSwap.Button";
constexpr std::size_t MaxSlots = 64;
constexpr std::size_t ChestArmorSlot = 1; // 0 head, 1 chest, 2 legs, 3 feet

struct ActorEquipmentComponent {
    void* hand;
    void* armorContainer;
};

template <class T>
T readAt(const void* object, std::size_t offset) {
    return *reinterpret_cast<const T*>(static_cast<const std::byte*>(object) + offset);
}

bool containerRange(const void* container, std::uintptr_t& begin, std::size_t& count) {
    begin = 0;
    count = 0;
    if (!container) return false;
    begin = readAt<std::uintptr_t>(container, FillingContainerItems);
    const auto end = readAt<std::uintptr_t>(container, FillingContainerItems + sizeof(void*));
    if (!begin || end < begin || begin % alignof(void*) != 0) return false;
    const auto bytes = end - begin;
    if (bytes % ItemStackSize != 0) return false;
    count = bytes / ItemStackSize;
    return count > 0 && count <= MaxSlots;
}

void* stackAt(std::uintptr_t begin, std::size_t slot) {
    return reinterpret_cast<void*>(begin + slot * ItemStackSize);
}

// true, если идентификатор предмета содержит part (например "elytra", "chestplate")
bool stackHas(const void* stack, std::string_view part) {
    if (!stack || part.empty() || !readAt<std::uint8_t>(stack, ItemStackValid)) return false;
    if (readAt<std::uint8_t>(stack, ItemStackCount) == 0) return false;
    const void* counter = readAt<const void*>(stack, ItemStackItemCounter);
    const void* item = counter ? readAt<const void*>(counter, 0) : nullptr;
    if (!item) return false;
    const auto* vtable = readAt<const std::uintptr_t*>(item, 0);
    if (!vtable || !vtable[ItemGetDescriptionIdVtableIndex]) return false;
    using GetDescriptionIdFn = const std::string& (*)(const void*);
    const auto& id = reinterpret_cast<GetDescriptionIdFn>(vtable[ItemGetDescriptionIdVtableIndex])(item);
    return id.size() <= 128 && id.find(part) != std::string::npos;
}

int chestplateScore(const void* stack) {
    static const char* order[] = {"netherite_chestplate", "diamond_chestplate", "iron_chestplate",
                                  "chainmail_chestplate", "golden_chestplate", "leather_chestplate"};
    for (int i = 0; i < 6; ++i)
        if (stackHas(stack, order[i])) return 6 - i;
    return stackHas(stack, "chestplate") ? 1 : 0;
}

void* armorContainerOf(void* player) {
    if (!player) return nullptr;
    auto* context = reinterpret_cast<EntityContext*>(
        reinterpret_cast<std::uintptr_t>(player) + bt::sdk::offsets::Actor::mEntityContext);
    auto* equipment = context->tryGetComponent<ActorEquipmentComponent>();
    return equipment ? equipment->armorContainer : nullptr;
}

void* mainInventoryOf(void* player) {
    if (!player) return nullptr;
    const void* proxy = readAt<const void*>(player, PlayerInventory);
    return proxy ? const_cast<void*>(readAt<const void*>(proxy, PlayerInventoryContainer)) : nullptr;
}

}

ElytraSwapModule::ElytraSwapModule()
    : Module("ElytraSwap", "Button that swaps your chestplate and elytra.") {}

void ElytraSwapModule::onInit() {
    gInstance = this;
    gh::setTickCallback([] { if (gInstance) gInstance->onTick(); });
    registerButton();
}

void ElytraSwapModule::onTick() {
    auto& st = gh::state();
    if (m_pending && st.gameMode) { m_pending = false; swap(); }
    if (m_dirty) { m_dirty = false; registerButton(); }
}

bool ElytraSwapModule::fail(const char* reason) {
    m_status = reason;
    m_dirty = true;
    return false;
}

bool ElytraSwapModule::swap() {
    if (!enabled) return fail("module off");
    if (m_swapping) return false;
    auto& st = gh::state();
    if (!st.installed) return fail("hooks not installed");
    if (!st.player) return fail("no player yet");
    if (!st.gameMode) {
        // GameMode появляется после первого действия (удар/блок/предмет) — свап выполнится сразу после него.
        m_pending = true;
        return fail("do any action (hit/place)");
    }

    std::uintptr_t armorBegin = 0;
    std::size_t armorCount = 0;
    if (!containerRange(armorContainerOf(st.player), armorBegin, armorCount) || armorCount <= ChestArmorSlot)
        return fail("armor read failed");
    const bool wearingElytra = stackHas(stackAt(armorBegin, ChestArmorSlot), "elytra");

    std::uintptr_t begin = 0;
    std::size_t count = 0;
    if (!containerRange(mainInventoryOf(st.player), begin, count)) return fail("inventory read failed");

    void* target = nullptr;
    int best = 0;
    for (std::size_t slot = 0; slot < count; ++slot) {
        void* stack = stackAt(begin, slot);
        if (wearingElytra) {
            const int sc = chestplateScore(stack);
            if (sc > best) { best = sc; target = stack; }
        } else if (stackHas(stack, "elytra")) {
            target = stack;
            break;
        }
    }
    if (!target) return fail(wearingElytra ? "no chestplate" : "no elytra");
    if (!gh::useItemAvailable(st.survival)) return fail("no useItem hook");

    m_swapping = true;
    const bool ok = gh::callUseItem(st.gameMode, st.survival, target);
    m_swapping = false;
    m_status = ok ? (wearingElytra ? "-> chestplate" : "-> elytra") : "useItem false";
    m_dirty = true;
    return ok;
}

void ElytraSwapModule::onKeybind(std::string_view key, bool isDown) {
    if (key == "keybind" && isDown) swap();
}

void ElytraSwapModule::registerButton() {
    // ДИАГНОСТИЧЕСКАЯ СБОРКА: текст на кнопке всегда виден.
    //   h:N/7      — сколько хуков игры установлено; P/G — есть ли игрок / игровой режим
    //   ev:X#N     — какое последнее событие пришло от кнопки и сколько их было
    //   дальше     — результат последней попытки свапа
    const std::string text = std::string("Elytra h:") + std::to_string(gh::state().hooked) + "/7" +
        (gh::state().player ? " P" : " -") + (gh::state().gameMode ? "G" : "-") +
        " ev:" + m_lastEvent + "#" + std::to_string(m_eventCount) + " " + m_status;
    pl::modmenu::ButtonBuilder(ButtonId, "Elytra Swap")
        .moduleId(id)
        .label(text)
        .behavior(pl::modmenu::ButtonBehavior::Click)
        .stylePreset(pl::modmenu::ButtonStylePreset::Keycap)
        .sizeScale(5.0f, 1.0f)
        .pngIcon(std::span<const unsigned char>(ElytraIconPng, sizeof(ElytraIconPng)), false)
        .onEvent([this](std::string_view, pl::modmenu::ButtonEvent event, float) {
            const char* name = "?";
            switch (event) {
                case pl::modmenu::ButtonEvent::Click: name = "Click"; break;
                case pl::modmenu::ButtonEvent::Down: name = "Down"; break;
                case pl::modmenu::ButtonEvent::Up: name = "Up"; break;
                case pl::modmenu::ButtonEvent::StateChanged: name = "State"; break;
                case pl::modmenu::ButtonEvent::Scroll: name = "Scroll"; break;
            }
            ++m_eventCount;
            m_lastEvent = name;
            m_dirty = true;

            // Реагируем на любое «нажатие», но не чаще раза в 400 мс (Down/Up/Click приходят пачкой).
            if (event == pl::modmenu::ButtonEvent::Click || event == pl::modmenu::ButtonEvent::Down ||
                event == pl::modmenu::ButtonEvent::StateChanged) {
                const long long now = std::chrono::duration_cast<std::chrono::milliseconds>(
                    std::chrono::steady_clock::now().time_since_epoch()).count();
                if (now - m_lastTriggerMs > 400) {
                    m_lastTriggerMs = now;
                    swap();
                }
            }
        })
        .registerButton();
}
