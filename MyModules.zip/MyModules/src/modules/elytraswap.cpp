#include "elytraswap.hpp"

#include <pl/ModMenuConfig.hpp>

#include <cstddef>
#include <cstdint>
#include <string>

namespace {

using namespace bedrocktools::sdk::offsets::Inventory;
namespace bt = bedrocktools;

constexpr const char* ButtonId = "mymodules.ElytraSwap.Button";
constexpr std::size_t MaxSlots = 64;
constexpr std::size_t ChestArmorSlot = 1; // 0 head, 1 chest, 2 legs, 3 feet

struct ActorEquipmentComponent {
    void* hand;
    void* armorContainer;
};

template <class T>
T readAt(const void* object, std::size_t offset) {
    return *reinterpret_cast<const T*>(static_cast<const std::byte*>(object) + offset);
}

bool containerRange(const void* container, std::uintptr_t& begin, std::size_t& count) {
    begin = 0;
    count = 0;
    if (!container) return false;
    begin = readAt<std::uintptr_t>(container, FillingContainerItems);
    const auto end = readAt<std::uintptr_t>(container, FillingContainerItems + sizeof(void*));
    if (!begin || end < begin || begin % alignof(void*) != 0) return false;
    const auto bytes = end - begin;
    if (bytes % ItemStackSize != 0) return false;
    count = bytes / ItemStackSize;
    return count > 0 && count <= MaxSlots;
}

void* stackAt(std::uintptr_t begin, std::size_t slot) {
    return reinterpret_cast<void*>(begin + slot * ItemStackSize);
}

// true, если идентификатор предмета содержит part (например "elytra", "chestplate")
bool stackHas(const void* stack, std::string_view part) {
    if (!stack || part.empty() || !readAt<std::uint8_t>(stack, ItemStackValid)) return false;
    if (readAt<std::uint8_t>(stack, ItemStackCount) == 0) return false;
    const void* counter = readAt<const void*>(stack, ItemStackItemCounter);
    const void* item = counter ? readAt<const void*>(counter, 0) : nullptr;
    if (!item) return false;
    const auto* vtable = readAt<const std::uintptr_t*>(item, 0);
    if (!vtable || !vtable[ItemGetDescriptionIdVtableIndex]) return false;
    using GetDescriptionIdFn = const std::string& (*)(const void*);
    const auto& id = reinterpret_cast<GetDescriptionIdFn>(vtable[ItemGetDescriptionIdVtableIndex])(item);
    return id.size() <= 128 && id.find(part) != std::string::npos;
}

int chestplateScore(const void* stack) {
    static const char* order[] = {"netherite_chestplate", "diamond_chestplate", "iron_chestplate",
                                  "chainmail_chestplate", "golden_chestplate", "leather_chestplate"};
    for (int i = 0; i < 6; ++i)
        if (stackHas(stack, order[i])) return 6 - i;
    return stackHas(stack, "chestplate") ? 1 : 0;
}

void* armorContainerOf(void* player) {
    if (!player) return nullptr;
    auto* context = reinterpret_cast<EntityContext*>(
        reinterpret_cast<std::uintptr_t>(player) + bt::sdk::offsets::Actor::mEntityContext);
    auto* equipment = context->tryGetComponent<ActorEquipmentComponent>();
    return equipment ? equipment->armorContainer : nullptr;
}

void* mainInventoryOf(void* player) {
    if (!player) return nullptr;
    const void* proxy = readAt<const void*>(player, PlayerInventory);
    return proxy ? const_cast<void*>(readAt<const void*>(proxy, PlayerInventoryContainer)) : nullptr;
}

}

ElytraSwapModule::ElytraSwapModule()
    : Module("ElytraSwap", "Button that swaps your chestplate and elytra. Requires BedrockTools.") {}

void ElytraSwapModule::onInit() {
    ensureRuntime();
    registerButton();
}

bool ElytraSwapModule::ensureRuntime() {
    if (m_api && m_tick && m_action) return true;
    m_api = bt::api::find();
    if (!m_api) return false;

    m_gameModeUseItem = reinterpret_cast<UseItemFn>(bt::api::resolve(bt::memory::SignatureId::GameModeUseItem, m_api));
    m_survivalModeUseItem = reinterpret_cast<UseItemFn>(bt::api::resolve(bt::memory::SignatureId::SurvivalModeUseItem, m_api));

    m_tick.subscribe([this](auto& e) { m_player = e.player; }, bt::events::EventPriority::Normal, m_api);
    m_action.subscribe([this](auto& e) {
        if (e.gameMode && !m_swapping) { m_gameMode = e.gameMode; m_modeKind = e.modeKind; }
    }, bt::events::EventPriority::Normal, m_api);
    return static_cast<bool>(m_tick) && static_cast<bool>(m_action);
}

bool ElytraSwapModule::swap() {
    if (!enabled || m_swapping || !ensureRuntime() || !m_player || !m_gameMode) return false;

    std::uintptr_t armorBegin = 0;
    std::size_t armorCount = 0;
    if (!containerRange(armorContainerOf(m_player), armorBegin, armorCount) || armorCount <= ChestArmorSlot) return false;
    const bool wearingElytra = stackHas(stackAt(armorBegin, ChestArmorSlot), "elytra");

    std::uintptr_t begin = 0;
    std::size_t count = 0;
    if (!containerRange(mainInventoryOf(m_player), begin, count)) return false;

    void* target = nullptr;
    int best = 0;
    for (std::size_t slot = 0; slot < count; ++slot) {
        void* stack = stackAt(begin, slot);
        if (wearingElytra) {
            const int s = chestplateScore(stack);
            if (s > best) { best = s; target = stack; }
        } else if (stackHas(stack, "elytra")) {
            target = stack;
            break;
        }
    }
    if (!target) return false;

    UseItemFn useItem = m_modeKind == bt::events::GameModeType::SurvivalMode ? m_survivalModeUseItem : m_gameModeUseItem;
    if (!useItem) return false;

    m_swapping = true;
    const bool ok = useItem(m_gameMode, target);
    m_swapping = false;
    return ok;
}

void ElytraSwapModule::onKeybind(std::string_view key, bool isDown) {
    if (key == "keybind" && isDown) swap();
}

void ElytraSwapModule::registerButton() {
    static const char* icon = R"svg(<svg viewBox="0 0 64 64" xmlns="http://www.w3.org/2000/svg">
    <path fill="#C6C6C6" stroke="#373737" stroke-width="2" d="M2,2 L62,2 L62,62 L2,62 Z"/>
    <path fill="#373737" d="M32,12 L10,34 L20,32 L32,52 L44,32 L54,34 Z"/>
</svg>)svg";
    pl::modmenu::ButtonBuilder(ButtonId, "Elytra")
        .moduleId(id)
        .behavior(pl::modmenu::ButtonBehavior::Toggle)
        .stylePreset(pl::modmenu::ButtonStylePreset::Accent)
        .styleColors(0x00000001, 0x00000001, 0x00000001)
        .svgIcon(icon)
        .activeSvgIcon(icon)
        .onEvent([this](std::string_view, pl::modmenu::ButtonEvent event, float) {
            if (event == pl::modmenu::ButtonEvent::StateChanged) swap();
        })
        .registerButton();
}
