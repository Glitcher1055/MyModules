#include "elytraswap.hpp"
#include "elytraswap_icon.hpp"

#include <pl/ModMenu.hpp>

#include <cstddef>
#include <span>
#include <cstdint>
#include <string>

namespace {

using namespace bedrocktools::sdk::offsets::Inventory;
namespace bt = bedrocktools;

constexpr const char* ButtonId = "mymodules.ElytraSwap.Button";
constexpr std::size_t MaxSlots = 64;
constexpr std::size_t ChestArmorSlot = 1; // 0 head, 1 chest, 2 legs, 3 feet

struct ActorEquipmentComponent {
    void* hand;
    void* armorContainer;
};

template <class T>
T readAt(const void* object, std::size_t offset) {
    return *reinterpret_cast<const T*>(static_cast<const std::byte*>(object) + offset);
}

bool containerRange(const void* container, std::uintptr_t& begin, std::size_t& count) {
    begin = 0;
    count = 0;
    if (!container) return false;
    begin = readAt<std::uintptr_t>(container, FillingContainerItems);
    const auto end = readAt<std::uintptr_t>(container, FillingContainerItems + sizeof(void*));
    if (!begin || end < begin || begin % alignof(void*) != 0) return false;
    const auto bytes = end - begin;
    if (bytes % ItemStackSize != 0) return false;
    count = bytes / ItemStackSize;
    return count > 0 && count <= MaxSlots;
}

void* stackAt(std::uintptr_t begin, std::size_t slot) {
    return reinterpret_cast<void*>(begin + slot * ItemStackSize);
}

// true, если идентификатор предмета содержит part (например "elytra", "chestplate")
bool stackHas(const void* stack, std::string_view part) {
    if (!stack || part.empty() || !readAt<std::uint8_t>(stack, ItemStackValid)) return false;
    if (readAt<std::uint8_t>(stack, ItemStackCount) == 0) return false;
    const void* counter = readAt<const void*>(stack, ItemStackItemCounter);
    const void* item = counter ? readAt<const void*>(counter, 0) : nullptr;
    if (!item) return false;
    const auto* vtable = readAt<const std::uintptr_t*>(item, 0);
    if (!vtable || !vtable[ItemGetDescriptionIdVtableIndex]) return false;
    using GetDescriptionIdFn = const std::string& (*)(const void*);
    const auto& id = reinterpret_cast<GetDescriptionIdFn>(vtable[ItemGetDescriptionIdVtableIndex])(item);
    return id.size() <= 128 && id.find(part) != std::string::npos;
}

int chestplateScore(const void* stack) {
    static const char* order[] = {"netherite_chestplate", "diamond_chestplate", "iron_chestplate",
                                  "chainmail_chestplate", "golden_chestplate", "leather_chestplate"};
    for (int i = 0; i < 6; ++i)
        if (stackHas(stack, order[i])) return 6 - i;
    return stackHas(stack, "chestplate") ? 1 : 0;
}

void* armorContainerOf(void* player) {
    if (!player) return nullptr;
    auto* context = reinterpret_cast<EntityContext*>(
        reinterpret_cast<std::uintptr_t>(player) + bt::sdk::offsets::Actor::mEntityContext);
    auto* equipment = context->tryGetComponent<ActorEquipmentComponent>();
    return equipment ? equipment->armorContainer : nullptr;
}

void* mainInventoryOf(void* player) {
    if (!player) return nullptr;
    const void* proxy = readAt<const void*>(player, PlayerInventory);
    return proxy ? const_cast<void*>(readAt<const void*>(proxy, PlayerInventoryContainer)) : nullptr;
}

}

ElytraSwapModule::ElytraSwapModule()
    : Module("ElytraSwap", "Button that swaps your chestplate and elytra. Requires BedrockTools.") {}

void ElytraSwapModule::onInit() {
    ensureRuntime();
    registerButton();
}

bool ElytraSwapModule::ensureRuntime() {
    if (m_api && m_tick && m_action) return true;
    m_api = bt::api::find();
    if (!m_api) return false;

    m_gameModeUseItem = reinterpret_cast<UseItemFn>(bt::api::resolve(bt::memory::SignatureId::GameModeUseItem, m_api));
    m_survivalModeUseItem = reinterpret_cast<UseItemFn>(bt::api::resolve(bt::memory::SignatureId::SurvivalModeUseItem, m_api));

    m_tick.subscribe([this](auto& e) {
        m_player = e.player;
        if (m_pending && m_gameMode) { m_pending = false; swap(); }
        if (m_dirty) { m_dirty = false; registerButton(); }
    }, bt::events::EventPriority::Normal, m_api);
    m_action.subscribe([this](auto& e) {
        if (e.gameMode && !m_swapping) { m_gameMode = e.gameMode; m_modeKind = e.modeKind; }
    }, bt::events::EventPriority::Normal, m_api);
    return static_cast<bool>(m_tick) && static_cast<bool>(m_action);
}

bool ElytraSwapModule::fail(const char* reason) {
    m_failed = true;
    m_status = reason;
    m_dirty = true;
    return false;
}

bool ElytraSwapModule::swap() {
    if (!enabled) return fail("module off");
    if (m_swapping) return false;
    if (!ensureRuntime()) return fail("no BedrockTools");
    if (!m_player) return fail("no player");
    if (!m_gameMode) {
        // GameMode появляется после первого действия (удар/установка блока) — выполним свап сразу после него.
        m_pending = true;
        return fail("do any action (hit/place)");
    }

    std::uintptr_t armorBegin = 0;
    std::size_t armorCount = 0;
    if (!containerRange(armorContainerOf(m_player), armorBegin, armorCount) || armorCount <= ChestArmorSlot)
        return fail("armor read failed");
    const bool wearingElytra = stackHas(stackAt(armorBegin, ChestArmorSlot), "elytra");

    std::uintptr_t begin = 0;
    std::size_t count = 0;
    if (!containerRange(mainInventoryOf(m_player), begin, count)) return fail("inventory read failed");

    void* target = nullptr;
    int best = 0;
    for (std::size_t slot = 0; slot < count; ++slot) {
        void* stack = stackAt(begin, slot);
        if (wearingElytra) {
            const int s = chestplateScore(stack);
            if (s > best) { best = s; target = stack; }
        } else if (stackHas(stack, "elytra")) {
            target = stack;
            break;
        }
    }
    if (!target) return fail(wearingElytra ? "no chestplate" : "no elytra");

    UseItemFn useItem = m_modeKind == bt::events::GameModeType::SurvivalMode ? m_survivalModeUseItem : m_gameModeUseItem;
    if (!useItem) return fail("no useItem sig");

    m_swapping = true;
    const bool ok = useItem(m_gameMode, target);
    m_swapping = false;
    m_failed = !ok;
    m_status = ok ? (wearingElytra ? "-> chestplate" : "-> elytra") : "useItem false";
    m_dirty = true;
    return ok;
}

void ElytraSwapModule::onKeybind(std::string_view key, bool isDown) {
    if (key == "keybind" && isDown) swap();
}

void ElytraSwapModule::registerButton() {
    // Обычно только иконка. При сбое поверх показывается причина, после успеха — снова чистая иконка.
    const bool showText = m_failed;
    pl::modmenu::ButtonBuilder(ButtonId, "Elytra Swap")
        .moduleId(id)
        .label(showText ? ("Elytra: " + m_status) : std::string("Elytra"))
        .behavior(pl::modmenu::ButtonBehavior::Click)
        .stylePreset(pl::modmenu::ButtonStylePreset::Keycap)
        .sizeScale(showText ? 3.5f : 1.0f, 1.0f)
        .pngIcon(std::span<const unsigned char>(ElytraIconPng, sizeof(ElytraIconPng)), !showText)
        .onEvent([this](std::string_view, pl::modmenu::ButtonEvent event, float) {
            if (event == pl::modmenu::ButtonEvent::Click) swap();
        })
        .registerButton();
}
