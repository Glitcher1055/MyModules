#include "GameHooks.hpp"
#include "Registry.hpp"

#include <pl/Mod.hpp>
#include <pl/ModMenu.hpp>
#include <string_view>

static void onToggle(std::string_view id, bool on) {
    if (auto* m = Registry::get().find(id)) m->enabled = on;
}

static void onKeybind(std::string_view id, std::string_view key, bool isDown) {
    if (auto* m = Registry::get().find(id)) if (m->enabled) m->onKeybind(key, isDown);
}

static void registerMenu() {
    for (auto& m : Registry::get().modules()) {
        pl::modmenu::ModuleBuilder builder(m->id, m->name);
        builder.description(m->description)
               .defaultEnabled(true)
               .onToggle(onToggle)
               .onKeybind(onKeybind)
               .config("keybind", "Keybind", pl::modmenu::ConfigType::Keybind, "0", "", "", "");
        builder.registerModule();
    }
}

class MyModulesMod {
public:
    static MyModulesMod& instance() { static MyModulesMod mod; return mod; }
    bool load(pl::mod::ModContext&) { return true; }
    bool enable(pl::mod::ModContext&) {
        Registry::get().registerAll();
        registerMenu();
        gh::start();   // свои хуки игры, BedrockTools не нужен
        return true;
    }
    bool disable(pl::mod::ModContext&) { return true; }
    bool unload(pl::mod::ModContext&) { return true; }
};

PL_REGISTER_MOD(MyModulesMod, MyModulesMod::instance())
