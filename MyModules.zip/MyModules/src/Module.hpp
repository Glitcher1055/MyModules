#pragma once

#include <string>
#include <string_view>

// Базовый класс модуля. Новый модуль = новый класс + одна строка в Registry.cpp.
class Module {
public:
    std::string name;
    std::string description;
    std::string id;
    bool enabled = true;

    Module(std::string n, std::string d)
        : name(std::move(n)), description(std::move(d)), id("mymodules." + name) {}
    virtual ~Module() = default;

    virtual void onInit() {}
    virtual void onKeybind(std::string_view key, bool isDown) {}
};
