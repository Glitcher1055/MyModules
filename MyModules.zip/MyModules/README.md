# MyModules

Свои модули для LeviLauncher (Minecraft Bedrock, Android). Работают поверх
[BedrockTools](https://github.com/QYCottage/BedrockTools) — он должен быть установлен и включён:
отсюда берутся события игры и адреса функций (через его публичный API).

## Модули
- **ElytraSwap** — кнопка на экране: нагрудник <-> элитры.

## Как добавить модуль
1. Создай `src/modules/имя.hpp/.cpp` (класс от `Module`, как `ElytraSwapModule`).
2. Добавь одну строку в `src/Registry.cpp`.
3. Запушь — GitHub Actions соберёт `libMyModules.so`.

## Сборка без компьютера
Вкладка **Actions → Build → Run workflow**, затем скачай `libMyModules.so`
из Artifacts и добавь его как мод в LeviLauncher.

Папка `include/bedrocktools` — публичные заголовки BedrockTools (лицензия MIT, см. LICENSE.bedrocktools-MIT).
