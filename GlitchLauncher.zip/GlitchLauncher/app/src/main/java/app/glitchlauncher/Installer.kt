package app.glitchlauncher

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import org.json.JSONObject
import java.io.File
import java.net.URL
import java.security.MessageDigest
import java.util.concurrent.atomic.AtomicInteger

data class McVersion(val id: String, val type: String, val url: String)

/** Скачивает версии Minecraft с серверов Mojang: json, клиент, библиотеки, ассеты (с проверкой SHA-1). */
object Installer {
    private const val MANIFEST = "https://piston-meta.mojang.com/mc/game/version_manifest_v2.json"
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var started = false

    var versions by mutableStateOf<List<McVersion>>(emptyList())
    var lastError by mutableStateOf<String?>(null)
    val installed = mutableStateListOf<String>()
    val progress = mutableStateMapOf<String, Float>()

    fun root(c: Context) = File(c.getExternalFilesDir(null) ?: c.filesDir, "game")

    fun init(c: Context) {
        if (started) return
        started = true
        reload(c)
    }

    fun reload(c: Context) {
        val app = c.applicationContext
        lastError = null
        installed.clear()
        File(root(app), "versions").listFiles()?.filter { File(it, ".ok").exists() }?.forEach { installed.add(it.name) }
        scope.launch {
            try {
                val arr = JSONObject(URL(MANIFEST).readText()).getJSONArray("versions")
                versions = (0 until arr.length()).map {
                    val o = arr.getJSONObject(it)
                    McVersion(o.getString("id"), o.getString("type"), o.getString("url"))
                }
            } catch (e: Exception) {
                lastError = "Нет связи с Mojang: ${e.message}"
            }
        }
    }

    fun install(c: Context, v: McVersion) {
        if (progress.containsKey(v.id)) return
        val app = c.applicationContext
        progress[v.id] = 0f
        scope.launch {
            try {
                run(app, v)
                installed.add(v.id)
            } catch (e: Exception) {
                lastError = "Ошибка ${v.id}: ${e.message}"
            } finally {
                progress.remove(v.id)
            }
        }
    }

    private suspend fun run(c: Context, v: McVersion) {
        val base = root(c)
        val vd = File(base, "versions/${v.id}")
        val vFile = File(vd, "${v.id}.json")
        fetch(v.url, vFile, null)
        val j = JSONObject(vFile.readText())
        val tasks = mutableListOf<Triple<String, File, String?>>()
        val client = j.getJSONObject("downloads").getJSONObject("client")
        tasks += Triple(client.getString("url"), File(vd, "${v.id}.jar"), client.optString("sha1"))
        val libs = j.getJSONArray("libraries")
        for (i in 0 until libs.length()) {
            val l = libs.getJSONObject(i)
            if (!allowed(l)) continue
            val a = l.optJSONObject("downloads")?.optJSONObject("artifact") ?: continue
            tasks += Triple(a.getString("url"), File(base, "libraries/" + a.getString("path")), a.optString("sha1"))
        }
        val ai = j.getJSONObject("assetIndex")
        val idx = File(base, "assets/indexes/${ai.getString("id")}.json")
        fetch(ai.getString("url"), idx, ai.optString("sha1"))
        val objs = JSONObject(idx.readText()).getJSONObject("objects")
        for (k in objs.keys()) {
            val h = objs.getJSONObject(k).getString("hash")
            val d = h.substring(0, 2)
            tasks += Triple("https://resources.download.minecraft.net/$d/$h", File(base, "assets/objects/$d/$h"), h)
        }
        val total = tasks.size
        val done = AtomicInteger(0)
        val sem = Semaphore(8)
        coroutineScope {
            tasks.map { t ->
                async {
                    sem.withPermit { fetch(t.first, t.second, t.third) }
                    progress[v.id] = done.incrementAndGet().toFloat() / total
                }
            }.awaitAll()
        }
        File(vd, ".ok").writeText("1")
    }

    private fun allowed(l: JSONObject): Boolean {
        val r = l.optJSONArray("rules") ?: return true
        var ok = false
        for (i in 0 until r.length()) {
            val o = r.getJSONObject(i)
            val os = o.optJSONObject("os")?.optString("name")
            if (os == null || os == "linux") ok = o.getString("action") == "allow"
        }
        return ok
    }

    private fun fetch(url: String, f: File, sha1: String?) {
        if (f.exists() && (sha1.isNullOrEmpty() || sha1Of(f) == sha1)) return
        f.parentFile?.mkdirs()
        val tmp = File(f.path + ".part")
        URL(url).openStream().use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
        if (!sha1.isNullOrEmpty() && sha1Of(tmp) != sha1) {
            tmp.delete()
            throw IllegalStateException("не совпал хеш файла ${f.name}")
        }
        tmp.renameTo(f)
    }

    private fun sha1Of(f: File): String {
        val m = MessageDigest.getInstance("SHA-1")
        f.inputStream().use { i ->
            val b = ByteArray(65536)
            while (true) { val n = i.read(b); if (n < 0) break; m.update(b, 0, n) }
        }
        return m.digest().joinToString("") { "%02x".format(it) }
    }
}
