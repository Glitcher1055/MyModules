package app.glitchlauncher

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF070B16)
private val PanelC = Color(0xFF10131C)
private val Line = Color(0xFF1D2232)
private val Mut = Color(0xFF7F8AA6)
private val Acc = Color(0xFF5B8CFF)
private val G1 = Color(0xFF00E5FF)
private val G2 = Color(0xFFFF2E93)

/** Точка подключения ядра MojoLauncher: здесь нужно вызвать запуск Java-игры. */
object GameLauncher {
    fun launch(version: String, loader: String, ramGb: Int) {
        // TODO: передать параметры в рантайм MojoLauncher
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}

@Composable
fun App() {
    var tab by remember { mutableIntStateOf(0) }
    MaterialTheme(colorScheme = darkColorScheme(primary = Acc, background = Bg, surface = PanelC)) {
        Column(
            Modifier.fillMaxSize()
                .background(Brush.verticalGradient(listOf(Bg, Color(0xFF0D1A3A))))
                .systemBarsPadding()
        ) {
            Row(
                Modifier.fillMaxWidth().padding(16.dp, 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Logo()
                Text("Player", color = Mut, fontSize = 12.sp)
            }
            Box(Modifier.weight(1f)) {
                when (tab) { 0 -> PlayScreen(); 1 -> SettingsScreen(); else -> ModsScreen() }
            }
            NavigationBar(containerColor = Color(0xFF080B14)) {
                listOf("Играть" to Icons.Default.PlayArrow, "Настройки" to Icons.Default.Settings, "Моды" to Icons.Default.Build)
                    .forEachIndexed { i, (label, icon) ->
                        NavigationBarItem(
                            selected = tab == i, onClick = { tab = i },
                            icon = { Icon(icon, label) }, label = { Text(label, fontSize = 10.sp) }
                        )
                    }
            }
        }
    }
}

@Composable
fun Logo() {
    Box {
        Text("GlitchLauncher", color = G1, fontWeight = FontWeight.Bold, fontSize = 17.sp, modifier = Modifier.offset((-1.5).dp))
        Text("GlitchLauncher", color = G2, fontWeight = FontWeight.Bold, fontSize = 17.sp, modifier = Modifier.offset(1.5.dp))
        Text("GlitchLauncher", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
    }
}

@Composable
fun Panel(title: String? = null, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Column(
        Modifier.fillMaxWidth().padding(bottom = 12.dp)
            .clip(shape).background(PanelC).border(1.dp, Line, shape).padding(14.dp)
    ) {
        if (title != null) Text(title, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.White, modifier = Modifier.padding(bottom = 8.dp))
        content()
    }
}

@Composable
fun ToggleRow(label: String, start: Boolean = false) {
    var on by remember { mutableStateOf(start) }
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = Color.White, fontSize = 14.sp)
        Switch(checked = on, onCheckedChange = { on = it })
    }
}

@Composable
fun Seg(items: List<String>, sel: Int, onSel: (Int) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(bottom = 12.dp)
            .clip(RoundedCornerShape(12.dp)).background(Color(0xFF0B0E16)).padding(3.dp)
    ) {
        items.forEachIndexed { i, t ->
            Box(
                Modifier.weight(1f).clip(RoundedCornerShape(9.dp))
                    .background(if (i == sel) Color(0xFFE8ECF6) else Color.Transparent)
                    .clickable { onSel(i) }.padding(vertical = 9.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(t, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = if (i == sel) Color(0xFF0B0E16) else Mut)
            }
        }
    }
}

@Composable
fun PlayScreen() {
    val versions = listOf("1.21.11", "1.20.1", "1.19.4")
    val loaders = listOf("Fabric", "Forge", "Vanilla")
    var v by remember { mutableIntStateOf(0) }
    var l by remember { mutableIntStateOf(0) }
    Box(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Column {
            Box(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp))
                    .background(Brush.horizontalGradient(listOf(Color(0xFF0F2A6B), Color(0xFF3B1D7A), Color(0xFF7A1D56))))
                    .padding(18.dp)
            ) {
                Column {
                    Text("Добро пожаловать", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = Color.White)
                    Text("Выберите версию и загрузчик внизу, затем нажмите «Играть».", color = Color(0xFFC6CFE8), fontSize = 13.sp)
                }
            }
        }
        Row(
            Modifier.align(Alignment.BottomCenter).padding(bottom = 10.dp).fillMaxWidth()
                .clip(RoundedCornerShape(22.dp)).background(Color(0xEE0C101B)).padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f).clickable { v = (v + 1) % versions.size }.padding(8.dp)) {
                Text("Версия", color = Mut, fontSize = 11.sp)
                Text(versions[v] + " ▾", color = Color.White, fontWeight = FontWeight.SemiBold)
            }
            Button(
                onClick = { GameLauncher.launch(versions[v], loaders[l], 4) },
                modifier = Modifier.weight(1.3f).height(52.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1A2F78))
            ) { Text("ИГРАТЬ", fontWeight = FontWeight.Bold, letterSpacing = 1.sp) }
            Column(Modifier.weight(1f).clickable { l = (l + 1) % loaders.size }.padding(8.dp), horizontalAlignment = Alignment.End) {
                Text("Загрузчик", color = Mut, fontSize = 11.sp)
                Text(loaders[l] + " ▾", color = Color.White, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
fun SettingsScreen() {
    var t by remember { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
        Seg(listOf("Игра", "Версии", "Лаунчер"), t) { t = it }
        when (t) {
            0 -> {
                var ram by remember { mutableFloatStateOf(4f) }
                var jvm by remember { mutableStateOf("-XX:+UseG1GC\n-XX:MaxGCPauseMillis=50") }
                Panel("Оперативная память") {
                    Text("${ram.toInt()} ГБ", color = Mut)
                    Slider(value = ram, onValueChange = { ram = it }, valueRange = 1f..8f, steps = 6)
                }
                Panel("Аргументы JVM") {
                    OutlinedTextField(value = jvm, onValueChange = { jvm = it }, modifier = Modifier.fillMaxWidth())
                }
                Panel("Запуск") {
                    ToggleRow("Показывать консоль")
                    ToggleRow("Закрывать лаунчер")
                }
            }
            1 -> Panel("Доступные версии") {
                listOf("1.21.11" to true, "1.20.1" to true, "1.19.4" to false).forEach { (name, installed) ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(name, color = Color.White, fontWeight = FontWeight.SemiBold)
                        OutlinedButton(onClick = { }) { Text(if (installed) "Файлы" else "Скачать") }
                    }
                }
            }
            else -> {
                Panel("Лаунчер") {
                    ToggleRow("Звуки интерфейса", true)
                    ToggleRow("Отключить анимации")
                }
                Panel("Кэш и данные") {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { }) { Text("Очистить кэш") }
                        OutlinedButton(onClick = { }) { Text("Экспорт") }
                    }
                }
            }
        }
    }
}

@Composable
fun ModsScreen() {
    var src by remember { mutableIntStateOf(0) }
    var q by remember { mutableStateOf("") }
    val mods = listOf(
        Triple("Just Enough Items", "Рецепты и предметы", Color(0xFF2D8F4E)),
        Triple("ModernFix", "Меньше памяти, быстрее загрузка", Color(0xFFC9A227)),
        Triple("Xaero’s World Map", "Полная карта мира", Color(0xFF3B7BD9)),
        Triple("Controlling", "Поиск по клавишам", Color(0xFF8A5CF5)),
        Triple("Entity Culling", "Скрывает невидимые сущности", Color(0xFFD9573B)),
        Triple("Jade", "Подсказки о блоках", Color(0xFF2AA7A0))
    ).filter { it.first.contains(q, ignoreCase = true) }
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Seg(listOf("Modrinth", "CurseForge"), src) { src = it }
        OutlinedTextField(value = q, onValueChange = { q = it }, placeholder = { Text("Поиск модов") }, singleLine = true, modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp))
        LazyVerticalGrid(GridCells.Fixed(2), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(mods) { (name, desc, color) ->
                val shape = RoundedCornerShape(14.dp)
                Column(Modifier.clip(shape).background(PanelC).border(1.dp, Line, shape).padding(10.dp).heightIn(min = 120.dp)) {
                    Box(Modifier.size(34.dp).clip(RoundedCornerShape(9.dp)).background(color))
                    Text(name, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
                    Text(desc, color = Mut, fontSize = 11.sp)
                }
            }
        }
    }
}
