// Entry point. PL_REGISTER_MOD must be used exactly once, here.
#include <pl/Mod.hpp>

#include "AttackMod.hpp"

PL_REGISTER_MOD(AttackMod, AttackMod::instance())
