#pragma once

// Everything that touches Minecraft internals lives here.

#include <string>

namespace attack::game {

// Finds HitResult::getEntity in libminecraftpe.so. `detail` receives a printable address.
bool resolveHookTarget(void *&target, std::string &detail);

// Presses / releases a mouse button in the game through the launcher's own native
// helper (the one its on-screen buttons use). Android codes: 1 = left, 2 = right.
bool sendMouse(int androidButton, bool down);

} // namespace attack::game
