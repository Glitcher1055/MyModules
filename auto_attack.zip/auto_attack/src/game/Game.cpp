#include "game/Game.hpp"

#include <cstdint>
#include <cstdio>

#include <dlfcn.h>

#include <pl/memory/Signature.hpp>

#include "Report.hpp"

namespace attack::game {
namespace {

// HitResult::getEntity (BedrockTools signature "HitResultGetEntity"; matches exactly once
// in libminecraftpe.so 1.26.50.4). The game calls it with the HitResult it is looking at
// (what the crosshair points at) and gets the entity back, or null when there is none.
constexpr const char *kSigHitResultGetEntity =
    "? ? ? D1 ? ? ? A9 ? ? ? F9 ? ? ? 91 53 D0 3B D5 E8 03 00 AA ? ? ? 91 ? ? ? F9 ? ? ? 91 ? ? ? F8 ? ? ? 94 ? ? ? 91 ? ? ? 94 ? ? ? 36 ? ? ? 91 ? ? ? 52";

using InitFn = unsigned char (*)(void *, void *);
using MouseFn = void (*)(void *, void *, int, unsigned char);

MouseFn gMouse = nullptr;
bool gHelperTried = false;

void loadHelper() {
  if (gHelperTried) return;
  gHelperTried = true;
  void *lib = dlopen("libinbuiltmods.so", RTLD_NOW | RTLD_NOLOAD);
  if (!lib) lib = dlopen("libinbuiltmods.so", RTLD_NOW);
  InitFn init = nullptr;
  if (lib) {
    init = reinterpret_cast<InitFn>(dlsym(
        lib, "Java_org_levimc_launcher_core_mods_inbuilt_nativemod_MoreButtonsMod_nativeInit"));
    gMouse = reinterpret_cast<MouseFn>(dlsym(
        lib, "Java_org_levimc_launcher_core_mods_inbuilt_nativemod_PojavControlsMod_nativeSendMouseButton"));
  }
  elytra::report::line("Input helper: lib=%p init=%p mouse=%p", lib, reinterpret_cast<void *>(init),
                       reinterpret_cast<void *>(gMouse));
  if (init) init(nullptr, nullptr);
}

} // namespace

bool resolveHookTarget(void *&target, std::string &detail) {
  const std::uintptr_t addr = pl::memory::resolveSignature(kSigHitResultGetEntity, "libminecraftpe.so");
  char buf[96];
  std::snprintf(buf, sizeof(buf), "HitResultGetEntity=0x%llx", static_cast<unsigned long long>(addr));
  detail = buf;
  if (!addr) return false;
  target = reinterpret_cast<void *>(addr);
  return true;
}

bool sendMouse(int androidButton, bool down) {
  loadHelper();
  if (!gMouse) return false;
  gMouse(nullptr, nullptr, androidButton, down ? 1 : 0);
  return true;
}

} // namespace attack::game
