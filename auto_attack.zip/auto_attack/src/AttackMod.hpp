#pragma once

#include <atomic>
#include <mutex>
#include <string>
#include <thread>

#include <pl/Mod.hpp>
#include <pl/memory/Hook.hpp>

#include "game/Game.hpp"

class AttackMod {
public:
  static AttackMod &instance();

  AttackMod();

  [[nodiscard]] ll::mod::NativeMod &getSelf() const { return mSelf; }

  bool load();
  bool enable();
  bool disable();
  bool unload();

  // Called from the on-screen button (Android UI thread).
  void toggle();

  // Hook on HitResult::getEntity: remembers when the game last saw an entity under the crosshair.
  static void *entityDetour(void *hitResult);

private:
  bool registerButton(int opacityPercent);
  void loadOpacity();
  void setOpacity(int percent);

  bool tryInstallHook();
  void workerLoop();
  void showMessage(const std::string &text, bool on);
  void submitMessage();

  ll::mod::NativeMod &mSelf;

  pl::memory::HookHandle mHook;
  std::thread mWorker;
  std::atomic<bool> mStop{false};
  std::atomic<bool> mHookInstalled{false};

  std::atomic<bool> mModuleOn{true}; // the module switch in the menu
  std::atomic<bool> mAttacking{false}; // the on-screen button state: auto attack on/off
  std::atomic<int> mOpacity{100};
  std::atomic<int> mDelayMs{250};
  std::atomic<long long> mLastToggleMs{0};

  // On-screen message ("Auto attack: ON/OFF").
  std::mutex mMsgMutex;
  std::string mMsgText;
  bool mMsgOn = false;
  long long mMsgUntilMs = 0;
  bool mMsgDirty = false;
  bool mMsgShown = false;
};
