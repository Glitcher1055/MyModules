#include "Report.hpp"

#include <chrono>
#include <cstdarg>
#include <cstdio>
#include <mutex>
#include <vector>

namespace elytra::report {
namespace {

std::mutex gMutex;
std::vector<FILE *> gFiles;
std::string gPrimary;
std::chrono::steady_clock::time_point gStart = std::chrono::steady_clock::now();

// Second copy: the launcher's own media folder, easy to find in a file manager
// (Android/media/org.levimc.launcher). Failure to open it is fine.
constexpr const char *kMediaCopy = "/sdcard/Android/media/org.levimc.launcher/auto_attack_report.txt";

void closeAll() {
  for (FILE *f : gFiles)
    if (f) fclose(f);
  gFiles.clear();
}

} // namespace

void init(const std::filesystem::path &dataDir) {
  std::lock_guard<std::mutex> lock(gMutex);
  closeAll();
  gStart = std::chrono::steady_clock::now();

  std::error_code ec;
  std::filesystem::create_directories(dataDir, ec);
  gPrimary = (dataDir / "auto_attack_report.txt").string();

  if (FILE *f = fopen(gPrimary.c_str(), "w")) gFiles.push_back(f);
  if (FILE *f = fopen(kMediaCopy, "w")) gFiles.push_back(f);

  for (FILE *f : gFiles) {
    fputs("Elytra Swap diagnostic report\n", f);
    fflush(f);
  }
}

void line(const char *fmt, ...) {
  char buf[2048];
  va_list args;
  va_start(args, fmt);
  vsnprintf(buf, sizeof(buf), fmt, args);
  va_end(args);

  std::lock_guard<std::mutex> lock(gMutex);
  const double secs =
      std::chrono::duration<double>(std::chrono::steady_clock::now() - gStart).count();
  for (FILE *f : gFiles) {
    fprintf(f, "[%8.3f] %s\n", secs, buf);
    fflush(f);
  }
}

std::string primaryPath() {
  std::lock_guard<std::mutex> lock(gMutex);
  return gPrimary;
}

} // namespace elytra::report
