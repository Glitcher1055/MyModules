#include "AttackMod.hpp"

#include <chrono>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <span>
#include <string>
#include <string_view>

#include <pl/ModMenu.hpp>

#include "Icon.hpp"
#include "Report.hpp"

namespace game = attack::game;
namespace report = elytra::report;

namespace {

constexpr const char *ModuleId = "auto_attack.module";
constexpr const char *ButtonId = "auto_attack.toggle";

constexpr long long DebounceMs = 250;
constexpr long long MessageMs = 2000;   // how long the on/off message stays on screen
constexpr long long FreshMs = 150;      // an entity seen this recently counts as "under the crosshair"
constexpr int LoopSleepMs = 20;
constexpr int ClickHoldMs = 35;         // how long the simulated click is held
constexpr int MouseLeft = 1;            // Android BUTTON_PRIMARY

using EntityFn = void *(*)(void *);
EntityFn gOriginalEntity = nullptr;

// Written by the hook (game thread), read by the worker thread.
std::atomic<long long> gLastEntityAtMs{0};
std::atomic<void *> gLastEntity{nullptr};
std::atomic<void *> gLastHitResult{nullptr};
std::atomic<unsigned> gCalls{0};
std::atomic<unsigned> gNonNull{0};

long long nowMs() {
  using namespace std::chrono;
  return duration_cast<milliseconds>(steady_clock::now().time_since_epoch()).count();
}

int clampOpacity(int percent) {
  int level = (percent + 5) / 10 * 10;
  if (level < 10) level = 10;
  if (level > 100) level = 100;
  return level;
}

float colorBits(std::uint32_t argb) {
  float f;
  std::memcpy(&f, &argb, sizeof(f));
  return f;
}

} // namespace

AttackMod &AttackMod::instance() {
  static AttackMod inst;
  return inst;
}

AttackMod::AttackMod() : mSelf(*ll::mod::NativeMod::current()) {}

bool AttackMod::load() {
  auto &self = getSelf();
  report::init(self.getDataDir());
  report::line("Auto Attack 0.1.0. Loaded as '%s'.", self.getName().c_str());
  report::line("Report file: %s", report::primaryPath().c_str());
  return true;
}

bool AttackMod::registerButton(int opacityPercent) {
  const auto &icon = kButtonIcons[clampOpacity(opacityPercent) / 10 - 1];
  return pl::modmenu::ButtonBuilder(ButtonId, "Auto Attack")
      .modId(getSelf().getId())
      .moduleId(ModuleId)
      .label("")
      .pngIcon(std::span<const unsigned char>(icon.data, icon.size))
      .sizeScale(1.0f, 1.0f)
      // The picture already is the whole button: make the launcher's own
      // background and border (almost) invisible so nothing shows behind it.
      .styleColors(0x01000000u, 0x01000000u, 0x01000000u)
      .behavior(pl::modmenu::ButtonBehavior::Click)
      .onEvent([](std::string_view, pl::modmenu::ButtonEvent event, float) {
        if (event == pl::modmenu::ButtonEvent::Click || event == pl::modmenu::ButtonEvent::Down) {
          instance().toggle();
        }
      })
      .registerButton();
}

void AttackMod::loadOpacity() {
  std::ifstream in(getSelf().getDataDir() / "opacity.txt");
  int value = 100;
  if (in >> value) mOpacity.store(clampOpacity(value));
}

void AttackMod::setOpacity(int percent) {
  const int level = clampOpacity(percent);
  if (level == mOpacity.load()) return;
  mOpacity.store(level);
  {
    std::ofstream out(getSelf().getDataDir() / "opacity.txt", std::ios::trunc);
    out << level;
  }
  pl::modmenu::unregisterButton(ButtonId);
  const bool ok = registerButton(level);
  report::line("Opacity set to %d%% (button re-registered: %d)", level, ok);
}

bool AttackMod::enable() {
  auto &self = getSelf();
  loadOpacity();

  const bool moduleOk =
      pl::modmenu::ModuleBuilder(ModuleId, "Auto Attack")
          .modId(self.getId())
          .description("Button: auto attack on/off. While on, it hits whatever the crosshair points at.")
          .defaultEnabled(true)
          .onToggle([](std::string_view, bool enabled) {
            instance().mModuleOn.store(enabled);
            if (!enabled) instance().mAttacking.store(false);
          })
          .config("delay", "Attack delay (ms)", pl::modmenu::ConfigType::SliderInt,
                  std::to_string(mDelayMs.load()), "100", "1000")
          .config("opacity", "Button opacity (%)", pl::modmenu::ConfigType::SliderInt,
                  std::to_string(mOpacity.load()), "10", "100")
          .onConfigChanged([](std::string_view, std::string_view key, std::string_view value) {
            const int v = std::atoi(std::string(value).c_str());
            if (key == "opacity") instance().setOpacity(v);
            if (key == "delay" && v >= 50 && v <= 5000) instance().mDelayMs.store(v);
          })
          .registerModule();
  const bool buttonOk = registerButton(mOpacity.load());
  report::line("enable(): menu module registered=%d, button registered=%d", moduleOk, buttonOk);

  mStop.store(false);
  mWorker = std::thread([this] { workerLoop(); });
  return true;
}

bool AttackMod::disable() {
  mStop.store(true);
  if (mWorker.joinable()) mWorker.join();
  mHook.reset();
  mHookInstalled.store(false);
  mAttacking.store(false);
  pl::modmenu::submitDrawCommands(ModuleId, {});
  pl::modmenu::unregisterButton(ButtonId);
  pl::modmenu::unregisterModule(ModuleId);
  return true;
}

bool AttackMod::unload() { return true; }

void AttackMod::toggle() {
  if (!mModuleOn.load()) return;
  const long long now = nowMs();
  if (now - mLastToggleMs.load() < DebounceMs) return;
  mLastToggleMs.store(now);

  const bool on = !mAttacking.load();
  mAttacking.store(on);
  showMessage(on ? "Авто атака: ВКЛ" : "Авто атака: ВЫКЛ", on);
  report::line("Auto attack %s (hook installed: %d, getEntity calls so far: %u, with an entity: %u)",
               on ? "ON" : "OFF", mHookInstalled.load() ? 1 : 0, gCalls.load(), gNonNull.load());
}

void AttackMod::showMessage(const std::string &text, bool on) {
  std::lock_guard<std::mutex> lock(mMsgMutex);
  mMsgText = text;
  mMsgOn = on;
  mMsgUntilMs = nowMs() + MessageMs;
  mMsgDirty = true;
}

// Draws (or clears) the message at the bottom centre of the screen.
void AttackMod::submitMessage() {
  std::lock_guard<std::mutex> lock(mMsgMutex);
  const long long now = nowMs();
  const bool want = now < mMsgUntilMs;
  if (!mMsgDirty && want == mMsgShown) return;
  mMsgDirty = false;
  mMsgShown = want;

  if (!want) {
    pl::modmenu::submitDrawCommands(ModuleId, {});
    return;
  }
  pl::modmenu::DrawCommand cmd;
  cmd.type = pl::modmenu::DrawCommandType::Text;
  cmd.x = -20000.0f;            // horizontal centre of the screen
  cmd.y = -10000.0f - 150.0f;   // 150 px above the bottom edge
  cmd.w = -2.0f;                // centred text
  cmd.x3 = colorBits(0x99000000u); // dark, half-transparent background
  cmd.color = mMsgOn ? 0xFF55FF55u : 0xFFFF5555u;
  cmd.size = 44.0f;
  cmd.text = mMsgText;
  pl::modmenu::submitDrawCommands(ModuleId, std::span<const pl::modmenu::DrawCommand>(&cmd, 1));
}

// --- hook ---------------------------------------------------------------------

void *AttackMod::entityDetour(void *hitResult) {
  void *entity = gOriginalEntity ? gOriginalEntity(hitResult) : nullptr;
  gCalls.fetch_add(1, std::memory_order_relaxed);
  if (entity) {
    gNonNull.fetch_add(1, std::memory_order_relaxed);
    gLastEntity.store(entity, std::memory_order_relaxed);
    gLastHitResult.store(hitResult, std::memory_order_relaxed);
    gLastEntityAtMs.store(nowMs(), std::memory_order_relaxed);
  }
  return entity;
}

bool AttackMod::tryInstallHook() {
  void *target = nullptr;
  std::string detail;
  if (!game::resolveHookTarget(target, detail)) return false;
  report::line("Found %s", detail.c_str());

  mHook = pl::memory::HookHandle(target, reinterpret_cast<void *>(&AttackMod::entityDetour),
                                 reinterpret_cast<void **>(&gOriginalEntity),
                                 pl::memory::HookPriority::Normal);
  if (!mHook.installed()) {
    report::line("Hook install FAILED");
    mHook.reset();
    return false;
  }
  mHookInstalled.store(true);
  report::line("Hook installed. Press the button to turn auto attack on.");
  return true;
}

// --- worker thread: installs the hook, shows messages, clicks -------------------

void AttackMod::workerLoop() {
  int installTries = 0;
  long long lastClickMs = 0;
  long long lastStatsMs = nowMs();
  unsigned clicks = 0, lastCalls = 0, lastNonNull = 0;
  bool wasTargeting = false;

  while (!mStop.load()) {
    if (!mHookInstalled.load() && installTries < 120) {
      // libminecraftpe.so may not be ready right away: retry for a minute.
      static long long lastTry = 0;
      if (nowMs() - lastTry >= 500) {
        lastTry = nowMs();
        ++installTries;
        if (!tryInstallHook() && installTries == 120)
          report::line("GAVE UP: could not find the game function to hook.");
      }
    }

    submitMessage();

    const long long now = nowMs();
    if (mAttacking.load() && mModuleOn.load()) {
      const long long seen = gLastEntityAtMs.load(std::memory_order_relaxed);
      const bool targeting = seen != 0 && now - seen < FreshMs;
      if (targeting != wasTargeting) {
        wasTargeting = targeting;
        report::line(targeting ? "Target: entity %p (hit result %p)" : "Target lost.",
                     gLastEntity.load(), gLastHitResult.load());
      }
      if (targeting && now - lastClickMs >= mDelayMs.load()) {
        lastClickMs = now;
        if (!game::sendMouse(MouseLeft, true)) {
          report::line("Cannot click: the launcher's mouse helper is not available.");
          mAttacking.store(false);
        } else {
          std::this_thread::sleep_for(std::chrono::milliseconds(ClickHoldMs));
          game::sendMouse(MouseLeft, false);
          ++clicks;
        }
      }

      // A short status line every 3 seconds while auto attack is on.
      if (now - lastStatsMs >= 3000) {
        lastStatsMs = now;
        const unsigned calls = gCalls.load(), nonNull = gNonNull.load();
        report::line("Status: getEntity calls +%u, with an entity +%u, clicks total %u",
                     calls - lastCalls, nonNull - lastNonNull, clicks);
        lastCalls = calls;
        lastNonNull = nonNull;
      }
    } else {
      wasTargeting = false;
      lastStatsMs = now;
      lastCalls = gCalls.load();
      lastNonNull = gNonNull.load();
    }

    std::this_thread::sleep_for(std::chrono::milliseconds(LoopSleepMs));
  }
}
